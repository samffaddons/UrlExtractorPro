/* URL Extractor Pro v7 - Content Script */

(function () {
  'use strict';

  const CONTAINER_ID = 'url-extractor-pro-container';
  const SPACER_ID    = 'url-extractor-pro-spacer';

  // ─── Settings ────────────────────────────────────────────────────────────────

  const SETTING_DEFAULTS = {
    filterWords:              '',
    highlightWords:           '',
    matchMode:                'both',
    highlightColor:           '#ffff00',
    fontSize:                 16,
    linkOpenMode:             'foreground',  // foreground/background for table links
    newTabMode:               'foreground',  // Open in New Tab viewer mode
    highlightTabMode:         'foreground',
    openOnlyHighlighted:      false,
    autoOpenHighlighted:      false,
    confirmHighlighted:       true,
    confirmThreshold:         5,
    showHighlightedSection:   false,
    openUniqueOnly:           true,
    scrollToTable:            true,          // auto-scroll to table after extraction
    searchEngine:             'google',      // default search engine for domain/email searches
    searchOpenMode:           'foreground',  // foreground/background for search links
    eventHuntersEnabled:      false,         // Event Hunters List filter (disabled by default)
    sortCol:                  0,
    sortAsc:                  true
  };

  function getSettings() {
    return browser.storage.local.get(SETTING_DEFAULTS);
  }

  // ─── Event Hunters List ───────────────────────────────────────────────────────

  const EVENT_HUNTERS_WORDS = 'contact|committee|staff|team|board|about|employee|management|bestuur|bureau|medewerkers|over-ons|chi-siamo|chi_siamo|direttivo|vorstand|despre-noi|comitete|conducere|comite|nuestro-equipo|Kurullar|iletisim|conseil-administration|duzenlemekurulu|veranstaltungen|geschaeftsstelle|kapcsolat|ansatte|medarbeidere|kontakt|impressum|imprint|events|calendar|leadership|chair|equipe|contatti|organ|organization|crew|pdf|governance|council|epikoinonia|touch|ueber-uns|komitee|unternehmen|praesidium|ansprechpartner|om-oss|Styret|konferansekomit|tel:|o-nas|junta|junta-directiva|quienes-somos|bestyrelse|bestyrelsen|mitarbeitende|om-|odbori|upoznajte-tim|te-tim|O-nama|o-nama|odbori|nas-tym|vodstvo|kalender|styrelse|medarbetare|chi siamo|bize-ulasin|İletişim|consiliu-director|despre|bilimsel-kurul|duezenleme-kurulu|hakkimizda|yonetim-kurulu|İletişim|epikoinonia|epitropes|οργανωση|linkedin|esemenyek|rolunk|Elnökség|elnokseg|bizottsag|Elnokseg|Szervezeti|secretariat|people|meetus|yhteystiedot|who|comittees|expert|partner|structure|over|Geschäftsstelle|agenda|gesellschaft|Über-uns|Evénements|Geschaeftsfuehrung|stowarzyszenie|zarzad|o-centrum|prezydium|a-propos|persone|Yönetim|Kurulu|consiglio|netzwerk|nas-tim|Medarbejdere|nasi-clanovi|ueber|struktur|membres|qui-sommes-nous|wie-wij-zijn|wie-we-zijn|vezetoseg|loc|COMMITTEES|sekretariatet|Pořadatel|ledelse|comitato|Sekretariat|kontorer|Διοικητικό|Συμβούλιο|διοικητικό-συμβούλιο|Comités|um|starfsfolk|echipa|juhatus|équipe|o_nas|o-nas|office|esecutivo|whoarewe|Hakkımızda|contattaci|comitati'
    .split('|').map(w => w.trim().toLowerCase()).filter(Boolean);

  // ─── URL / percent-encoding helpers ──────────────────────────────────────────

  // Remove percent-encoded chars from tel/mailto strings
  // %2B → '' (plus sign used as separator), %20 / + / %2b → '' (spaces), etc.
  // We just strip ALL %XX sequences since we only want the raw digits/dashes
  function cleanTelNum(raw) {
    return raw
      .replace(/%[0-9a-fA-F]{2}/g, '')   // strip all %XX encoded chars
      .trim();
  }

  function cleanEmail(raw) {
    return raw
      .replace(/%[0-9a-fA-F]{2}/g, '')
      .trim();
  }

  // ─── Extraction ──────────────────────────────────────────────────────────────

  function extractFromDoc(doc) {
    const results = [];
    try {
      doc.querySelectorAll('a[href]').forEach(a => {
        const href    = a.href;
        const rawHref = a.getAttribute('href') || '';
        if (!href) return;
        const lc = href.toLowerCase();
        if (lc.startsWith('javascript:') || lc.startsWith('mailto:') || lc.startsWith('tel:')) return;
        if (href === '#') return;
        const rawText = (a.innerText || a.textContent || '').trim().replace(/\s+/g, ' ');
        const text    = rawText || 'No Title';
        results.push({ text, url: href, rawHref, noTitle: !rawText });
      });
    } catch (e) {}
    return results;
  }

  function extractSpecialFromDoc(doc) {
    const mailto = [], tel = [], linkedin = [];
    try {
      doc.querySelectorAll('a[href]').forEach(a => {
        const href    = a.href;
        const rawHref = (a.getAttribute('href') || '').trim();
        const lc      = href.toLowerCase();
        const rawText = (a.innerText || a.textContent || '').trim().replace(/\s+/g, ' ');

        if (lc.startsWith('mailto:')) {
          const rawEmail = href.slice(7).split('?')[0].trim() || href;
          const email    = cleanEmail(rawEmail);
          const text     = rawText || email;
          mailto.push({ text, url: href, rawHref, display: email });
        } else if (lc.startsWith('tel:')) {
          const rawNum = rawHref.replace(/^tel:/i, '').trim() || href.replace(/^tel:/i, '').trim();
          const num    = cleanTelNum(rawNum);
          if (num) tel.push({ url: href, rawHref, num });
        } else if (lc.includes('linkedin')) {
          const text = rawText || 'LinkedIn URL';
          linkedin.push({ text, url: href, rawHref });
        }
      });
    } catch (e) {}
    return { mailto, tel, linkedin };
  }

  function extractAllURLs(filterWords, matchMode, ignoreFilter, eventHuntersEnabled) {
    let all = extractFromDoc(document);
    document.querySelectorAll('iframe, frame').forEach(frame => {
      try {
        const fdoc = frame.contentDocument || frame.contentWindow.document;
        if (fdoc) all = all.concat(extractFromDoc(fdoc));
      } catch (e) {}
    });

    const seen = new Set();
    all = all.filter(item => {
      const key = item.text + '|||' + item.url;
      if (seen.has(key)) return false;
      seen.add(key); return true;
    });

    // Apply user filter words
    if (!ignoreFilter && filterWords && filterWords.trim()) {
      const words = filterWords.split('\n').map(w => w.trim().toLowerCase()).filter(Boolean);
      if (words.length) all = all.filter(item => wordMatches(item, words, matchMode));
    }

    // Apply Event Hunters List (pipe-separated words) — additional filter layer
    if (!ignoreFilter && eventHuntersEnabled) {
      const ehWords = EVENT_HUNTERS_WORDS;
      if (ehWords.length) all = all.filter(item => wordMatches(item, ehWords, matchMode));
    }

    const special = extractSpecialLinks();
    return { regular: all, special };
  }

  function extractSpecialLinks() {
    const allDocs = [document];
    document.querySelectorAll('iframe, frame').forEach(frame => {
      try {
        const fdoc = frame.contentDocument || frame.contentWindow.document;
        if (fdoc) allDocs.push(fdoc);
      } catch (e) {}
    });

    let mailtoAll = [], telAll = [], linkedinAll = [];
    allDocs.forEach(doc => {
      const s = extractSpecialFromDoc(doc);
      mailtoAll   = mailtoAll.concat(s.mailto);
      telAll      = telAll.concat(s.tel);
      linkedinAll = linkedinAll.concat(s.linkedin);
    });

    const seenMail = new Set();
    mailtoAll = mailtoAll.filter(i => {
      const k = i.url.toLowerCase();
      if (seenMail.has(k)) return false;
      seenMail.add(k); return true;
    });

    const seenTel = new Set();
    telAll = telAll.filter(i => {
      const k = i.num.replace(/\s/g, '').toLowerCase();
      if (seenTel.has(k)) return false;
      seenTel.add(k); return true;
    });

    const seenLi = new Set();
    linkedinAll = linkedinAll.filter(i => {
      const k = i.url.toLowerCase();
      if (seenLi.has(k)) return false;
      seenLi.add(k); return true;
    });

    return { mailto: mailtoAll, tel: telAll, linkedin: linkedinAll };
  }

  // ─── Match helper ─────────────────────────────────────────────────────────────

  function wordMatches(item, words, matchMode) {
    return words.some(w => {
      const inText = item.text.toLowerCase().includes(w);
      // For URL matching: check resolved URL, raw href, AND URL-decoded version
      const urlLc     = item.url.toLowerCase();
      const rawLc     = (item.rawHref || '').toLowerCase();
      const decodedLc = (() => { try { return decodeURIComponent(urlLc); } catch(e) { return urlLc; } })();
      const inUrl     = urlLc.includes(w) || rawLc.includes(w) || decodedLc.includes(w);
      if (matchMode === 'text') return inText;
      if (matchMode === 'url')  return inUrl;
      return inText || inUrl;
    });
  }

  // ─── Utilities ───────────────────────────────────────────────────────────────

  function bs(bg = '#f0f0f0', color = '#333', extra = '') {
    return `background:${bg};color:${color};border:none;padding:7px 13px;border-radius:5px;cursor:pointer;font-size:13px;white-space:nowrap;font-weight:600;${extra}`;
  }

  function escapeCsv(val) { return `"${String(val).replace(/"/g, '""')}"` }

  function timestamp() {
    const d = new Date();
    return d.getFullYear() +
      String(d.getMonth()+1).padStart(2,'0') +
      String(d.getDate()).padStart(2,'0') + 'T' +
      String(d.getHours()).padStart(2,'0') +
      String(d.getMinutes()).padStart(2,'0');
  }

  function downloadFile(content, filename, mime) {
    const blob = new Blob([content], { type: mime });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  }

  function uniqueByUrl(items) {
    const seen = new Set();
    return items.filter(item => {
      const k = item.url.toLowerCase();
      if (seen.has(k)) return false;
      seen.add(k); return true;
    });
  }

  // ─── Search engine URL builder ────────────────────────────────────────────────

  const SEARCH_ENGINES = {
    google:     q => `https://www.google.com/search?q=${encodeURIComponent(q)}`,
    bing:       q => `https://www.bing.com/search?q=${encodeURIComponent(q)}`,
    duckduckgo: q => `https://duckduckgo.com/?q=${encodeURIComponent(q)}`,
    ecosia:     q => `https://www.ecosia.org/search?q=${encodeURIComponent(q)}`,
    yandex:     q => `https://yandex.com/search/?text=${encodeURIComponent(q)}`,
    startpage:  q => `https://www.startpage.com/search?q=${encodeURIComponent(q)}`,
    qwant:      q => `https://www.qwant.com/?q=${encodeURIComponent(q)}`,
    yahoo:      q => `https://search.yahoo.com/search?p=${encodeURIComponent(q)}`,
    brave:      q => `https://search.brave.com/search?q=${encodeURIComponent(q)}`,
    searx:      q => `https://searx.be/search?q=${encodeURIComponent(q)}`
  };

  function buildSearchUrl(query, engine) {
    const fn = SEARCH_ENGINES[engine] || SEARCH_ENGINES.google;
    return fn(query);
  }

  function showConfirmDialog({ title, message, confirmLabel, cancelLabel }) {
    return new Promise(resolve => {
      const overlay = document.createElement('div');
      overlay.style.cssText = `all:initial;position:fixed;inset:0;background:rgba(0,0,0,0.55);z-index:2147483646;display:flex;align-items:center;justify-content:center;`;
      const box = document.createElement('div');
      box.style.cssText = `all:initial;display:block;background:#fff;border-radius:12px;padding:28px 30px;max-width:440px;width:90%;box-shadow:0 8px 32px rgba(0,0,0,0.28);font-family:Arial,sans-serif;font-size:15px;color:#222;box-sizing:border-box;`;
      const h = document.createElement('div');
      h.style.cssText = 'font-size:18px;font-weight:bold;color:#e67e22;margin-bottom:14px;';
      h.textContent = title;
      const msg = document.createElement('div');
      msg.style.cssText = 'line-height:1.6;margin-bottom:22px;color:#333;';
      msg.innerHTML = message;
      const btnRow = document.createElement('div');
      btnRow.style.cssText = 'display:flex;gap:12px;justify-content:flex-end;';
      const cancelBtn = document.createElement('button');
      cancelBtn.textContent = cancelLabel || 'Cancel';
      cancelBtn.style.cssText = `padding:9px 20px;border:1px solid #ccc;border-radius:6px;background:#f0f0f0;color:#333;font-size:14px;font-weight:600;cursor:pointer;`;
      cancelBtn.addEventListener('click', () => { overlay.remove(); resolve(false); });
      const confirmBtn = document.createElement('button');
      confirmBtn.textContent = confirmLabel || 'Continue';
      confirmBtn.style.cssText = `padding:9px 20px;border:none;border-radius:6px;background:#e67e22;color:#fff;font-size:14px;font-weight:600;cursor:pointer;`;
      confirmBtn.addEventListener('click', () => { overlay.remove(); resolve(true); });
      overlay.addEventListener('click', e => { if (e.target === overlay) { overlay.remove(); resolve(false); } });
      btnRow.appendChild(cancelBtn); btnRow.appendChild(confirmBtn);
      box.appendChild(h); box.appendChild(msg); box.appendChild(btnRow);
      overlay.appendChild(box);
      (document.body || document.documentElement).appendChild(overlay);
      confirmBtn.focus();
    });
  }

  function openUrls(urlList, foreground) {
    urlList.forEach((item, i) => {
      browser.runtime.sendMessage({
        action:     'openDirectTab',
        url:        item.url,
        foreground: foreground && i === 0
      });
    });
  }

  // ─── Go-to-table button (floating, visible when table is off-screen) ──────────

  function createGoToTableBtn(wrapperId) {
    const btn = document.createElement('button');
    btn.id = 'ue-goto-table-fab';
    btn.textContent = '📋 ▼ Go to Table';
    btn.style.cssText = `
      all:initial;
      position:fixed;bottom:22px;right:22px;z-index:2147483640;
      background:#3a7bd5;color:#fff;border:none;border-radius:24px;
      padding:10px 18px;font-size:13px;font-weight:700;font-family:Arial,sans-serif;
      cursor:pointer;box-shadow:0 4px 16px rgba(0,0,0,0.25);
      opacity:0;transition:opacity 0.3s;pointer-events:none;
    `;
    btn.addEventListener('click', () => {
      const w = document.getElementById(wrapperId);
      if (w) w.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    (document.body || document.documentElement).appendChild(btn);

    // Show/hide based on whether the table header is visible
    const observer = new IntersectionObserver(entries => {
      const visible = entries[0].isIntersecting;
      btn.style.opacity    = visible ? '0'    : '1';
      btn.style.pointerEvents = visible ? 'none' : 'auto';
    }, { threshold: 0.1 });

    const target = document.getElementById(wrapperId);
    if (target) observer.observe(target);

    return { btn, observer };
  }

  // ─── Special rows builder ─────────────────────────────────────────────────────

  function buildSpecialRows(special, highlightColor, hlWordList, matchMode, checkedMap, searchEngine, searchOpenMode) {
    const rows      = [];
    const cellStyle = 'padding:6px 10px;border:1px solid #ddd;word-break:break-word;';
    const numStyle  = 'padding:6px 8px;border:1px solid #ddd;color:#888;font-size:0.85em;text-align:center;';
    const cbStyle   = 'padding:5px 8px;border:1px solid #ddd;text-align:center;width:36px;';

    function makeSection(label, color) {
      const tr = document.createElement('tr');
      const td = document.createElement('td');
      td.colSpan = 5;
      td.style.cssText = `padding:8px 12px;background:${color};font-weight:bold;font-size:13px;color:#fff;border:1px solid #ddd;letter-spacing:0.3px;`;
      td.textContent = label;
      tr.appendChild(td); rows.push(tr);
    }

    function makeRow(label, displayUrl, href, copyValue) {
      const key     = label + '|||' + (href || displayUrl);
      const checked = checkedMap.get(key) !== false;
      const fakeItem = { text: label, url: href || displayUrl, rawHref: href || '' };
      const hl       = hlWordList.length > 0 && wordMatches(fakeItem, hlWordList, matchMode);
      const bg       = hl ? highlightColor : '#fff';

      const tr = document.createElement('tr');
      tr.style.cssText = `background:${bg};cursor:pointer;`;

      const tdCb = document.createElement('td');
      tdCb.style.cssText = cbStyle;
      const cb = document.createElement('input');
      cb.type = 'checkbox'; cb.checked = checked;
      cb.style.cssText = 'width:15px;height:15px;cursor:pointer;';
      cb.addEventListener('change', e => { e.stopPropagation(); checkedMap.set(key, cb.checked); });
      tdCb.appendChild(cb); tr.appendChild(tdCb);

      // # cell
      const tdNum = document.createElement('td');
      tdNum.style.cssText = numStyle + 'width:44px;';
      tdNum.textContent = '—';
      tr.appendChild(tdNum);

      // Text cell
      const tdText = document.createElement('td');
      tdText.style.cssText = cellStyle;
      if (href) {
        const a = document.createElement('a');
        a.href = href; a.title = href; a.textContent = label;
        a.style.cssText = 'color:#1a0dab;text-decoration:none;';
        a.target = '_blank'; a.rel = 'noopener noreferrer';
        a.addEventListener('click', e => e.stopPropagation());
        tdText.appendChild(a);
      } else {
        tdText.textContent = label;
        tdText.style.cssText += 'color:#333;font-style:italic;';
      }
      tr.appendChild(tdText);

      // URL/value cell with optional copy button
      const tdUrl = document.createElement('td');
      tdUrl.style.cssText = cellStyle + 'word-break:break-all;';
      const urlWrap = document.createElement('span');
      urlWrap.style.cssText = 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;';

      if (href) {
        const a = document.createElement('a');
        a.href = href; a.title = href; a.textContent = displayUrl;
        a.style.cssText = 'color:#006621;text-decoration:none;font-size:0.88em;';
        a.target = '_blank'; a.rel = 'noopener noreferrer';
        a.addEventListener('click', e => e.stopPropagation());
        urlWrap.appendChild(a);
      } else {
        const span = document.createElement('span');
        span.textContent = displayUrl;
        span.style.cssText = 'color:#444;font-size:0.9em;flex:1;';
        urlWrap.appendChild(span);
      }

      if (copyValue !== undefined && copyValue !== null) {
        const copyBtn = document.createElement('button');
        copyBtn.textContent = '📋 Copy';
        copyBtn.title = 'Copy: ' + copyValue;
        copyBtn.style.cssText = `background:#1565c0;color:#fff;border:none;padding:3px 9px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:600;white-space:nowrap;flex-shrink:0;`;
        copyBtn.addEventListener('click', e => {
          e.stopPropagation();
          navigator.clipboard.writeText(copyValue).then(() => {
            copyBtn.textContent = '✓ Copied!'; copyBtn.style.background = '#2e7d32';
            setTimeout(() => { copyBtn.textContent = '📋 Copy'; copyBtn.style.background = '#1565c0'; }, 1800);
          }).catch(() => {
            copyBtn.textContent = '✗ Failed';
            setTimeout(() => { copyBtn.textContent = '📋 Copy'; }, 1800);
          });
        });
        urlWrap.appendChild(copyBtn);
      }

      tdUrl.appendChild(urlWrap); tr.appendChild(tdUrl);

      // Go to top cell (↑ button on every row)
      const tdTop = document.createElement('td');
      tdTop.style.cssText = 'padding:4px 6px;border:1px solid #ddd;text-align:center;width:32px;';
      const topBtn = document.createElement('button');
      topBtn.textContent = '↑';
      topBtn.title = 'Go to top of page';
      topBtn.style.cssText = `background:transparent;border:1px solid #bbb;border-radius:3px;cursor:pointer;font-size:12px;color:#666;padding:2px 5px;`;
      topBtn.addEventListener('click', e => { e.stopPropagation(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
      tdTop.appendChild(topBtn); tr.appendChild(tdTop);

      tr.addEventListener('click', () => { cb.checked = !cb.checked; checkedMap.set(key, cb.checked); });
      rows.push(tr);
    }

    if (special.mailto.length > 0) {
      makeSection('📧  Mailto Links', '#2e7d32');
      special.mailto.forEach(item => {
        checkedMap.set(item.text + '|||' + item.url, true);
        // Build the row with search buttons injected into the URL cell
        const key     = item.text + '|||' + item.url;
        const fakeItem = { text: item.text, url: item.url, rawHref: item.rawHref || '' };
        const hl       = hlWordList.length > 0 && wordMatches(fakeItem, hlWordList, matchMode);
        const bg       = hl ? highlightColor : '#fff';
        const cellStyle = 'padding:6px 10px;border:1px solid #ddd;word-break:break-word;';
        const numStyle  = 'padding:6px 8px;border:1px solid #ddd;color:#888;font-size:0.85em;text-align:center;';
        const cbStyle   = 'padding:5px 8px;border:1px solid #ddd;text-align:center;width:36px;';

        const tr = document.createElement('tr');
        tr.style.cssText = `background:${bg};cursor:pointer;`;

        const tdCb = document.createElement('td');
        tdCb.style.cssText = cbStyle;
        const cb = document.createElement('input');
        cb.type = 'checkbox'; cb.checked = true;
        cb.style.cssText = 'width:15px;height:15px;cursor:pointer;';
        cb.addEventListener('change', e => { e.stopPropagation(); checkedMap.set(key, cb.checked); });
        tdCb.appendChild(cb); tr.appendChild(tdCb);

        const tdNum = document.createElement('td');
        tdNum.style.cssText = numStyle + 'width:44px;';
        tdNum.textContent = '—'; tr.appendChild(tdNum);

        const tdText = document.createElement('td');
        tdText.style.cssText = cellStyle;
        const aText = document.createElement('a');
        aText.href = item.url; aText.title = item.url; aText.textContent = item.text;
        aText.style.cssText = 'color:#1a0dab;text-decoration:none;';
        aText.target = '_blank'; aText.rel = 'noopener noreferrer';
        aText.addEventListener('click', e => e.stopPropagation());
        tdText.appendChild(aText); tr.appendChild(tdText);

        // URL cell: display email + search buttons
        const tdUrl = document.createElement('td');
        tdUrl.style.cssText = cellStyle + 'word-break:break-all;';
        const urlWrap = document.createElement('span');
        urlWrap.style.cssText = 'display:flex;align-items:center;gap:6px;flex-wrap:wrap;';

        const aEmail = document.createElement('a');
        aEmail.href = item.url; aEmail.title = item.url; aEmail.textContent = item.display;
        aEmail.style.cssText = 'color:#006621;text-decoration:none;font-size:0.88em;';
        aEmail.target = '_blank'; aEmail.rel = 'noopener noreferrer';
        aEmail.addEventListener('click', e => e.stopPropagation());
        urlWrap.appendChild(aEmail);

        // Search with quotes button
        const btnSearchQ = document.createElement('button');
        btnSearchQ.textContent = '🔍 "quotes"';
        btnSearchQ.title = `Search "${item.display}" with quotes`;
        btnSearchQ.style.cssText = 'background:#1b5e20;color:#fff;border:none;padding:3px 8px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:600;white-space:nowrap;flex-shrink:0;';
        btnSearchQ.addEventListener('click', e => {
          e.stopPropagation();
          const url = buildSearchUrl(`"${item.display}"`, searchEngine);
          window.open(url, searchOpenMode === 'background' ? '_blank' : '_blank');
          if (searchOpenMode === 'foreground') {
            browser.runtime.sendMessage({ action: 'openDirectTab', url, foreground: true });
          } else {
            browser.runtime.sendMessage({ action: 'openDirectTab', url, foreground: false });
          }
        });
        urlWrap.appendChild(btnSearchQ);

        // Search without quotes button
        const btnSearchNoQ = document.createElement('button');
        btnSearchNoQ.textContent = '🔍 no quotes';
        btnSearchNoQ.title = `Search ${item.display} without quotes`;
        btnSearchNoQ.style.cssText = 'background:#2e7d32;color:#fff;border:none;padding:3px 8px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:600;white-space:nowrap;flex-shrink:0;';
        btnSearchNoQ.addEventListener('click', e => {
          e.stopPropagation();
          const url = buildSearchUrl(item.display, searchEngine);
          browser.runtime.sendMessage({ action: 'openDirectTab', url, foreground: searchOpenMode === 'foreground' });
        });
        urlWrap.appendChild(btnSearchNoQ);

        tdUrl.appendChild(urlWrap); tr.appendChild(tdUrl);

        // ↑ top
        const tdTop = document.createElement('td');
        tdTop.style.cssText = 'padding:4px 6px;border:1px solid #ddd;text-align:center;width:32px;';
        const topBtn = document.createElement('button');
        topBtn.textContent = '↑'; topBtn.title = 'Go to top of page';
        topBtn.style.cssText = 'background:transparent;border:1px solid #bbb;border-radius:3px;cursor:pointer;font-size:12px;color:#666;padding:2px 5px;';
        topBtn.addEventListener('click', e => { e.stopPropagation(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
        tdTop.appendChild(topBtn); tr.appendChild(tdTop);

        tr.addEventListener('click', () => { cb.checked = !cb.checked; checkedMap.set(key, cb.checked); });
        rows.push(tr);
      });
    }

    if (special.tel.length > 0) {
      makeSection('📞  Tel Links', '#1565c0');
      if (special.tel.length === 1) {
        const t = special.tel[0];
        checkedMap.set(t.num + '|||' + t.url, true);
        makeRow(t.num, t.num, t.url, t.num);
      } else {
        special.tel.forEach(t => {
          checkedMap.set(t.num + '|||' + t.url, true);
          makeRow(t.num, t.num, t.url, t.num);
        });
        const combined   = special.tel.map(t => t.num).join(' // ');
        const summaryKey = 'All Tel: Links|||' + combined;
        checkedMap.set(summaryKey, true);
        makeRow('All Tel: Links', combined, null, combined);
      }
    }

    if (special.linkedin.length > 0) {
      makeSection('💼  LinkedIn URLs', '#0a66c2');
      special.linkedin.forEach(item => {
        checkedMap.set(item.text + '|||' + item.url, true);
        makeRow(item.text, item.url, item.url);
      });
    }

    return rows;
  }

  // ─── Page Info rows (always last in table) ────────────────────────────────────
  // Returns 2 <tr> elements: page title row + page URL row

  // ─── Dummy Email rows ─────────────────────────────────────────────────────────

  function buildDummyEmailRows(pageUrl, searchEngine, searchOpenMode) {
    const rows = [];
    if (!pageUrl) return rows;

    let rootDomain = '';
    try {
      const h = new URL(pageUrl).hostname.replace(/^www\./, '');
      const parts = h.split('.');
      rootDomain = parts.length > 2 ? parts.slice(-2).join('.') : h;
    } catch (e) { return rows; }
    if (!rootDomain) return rows;

    const cellStyle = 'padding:6px 10px;border:1px solid #ddd;word-break:break-word;';
    const numStyle  = 'padding:6px 8px;border:1px solid #ddd;color:#888;font-size:0.85em;text-align:center;';
    const cbStyle   = 'padding:5px 8px;border:1px solid #ddd;text-align:center;width:36px;';
    const bg        = '#f1f8e9';

    // Section header
    const hdrTr = document.createElement('tr');
    const hdrTd = document.createElement('td');
    hdrTd.colSpan = 5;
    hdrTd.style.cssText = 'padding:8px 12px;background:#558b2f;font-weight:bold;font-size:13px;color:#fff;border:1px solid #ddd;letter-spacing:0.3px;';
    hdrTd.textContent = `📨  Dummy Emails — ${rootDomain}`;
    hdrTr.appendChild(hdrTd); rows.push(hdrTr);

    const prefixes = ['info', 'contactus'];

    prefixes.forEach(prefix => {
      const email    = `${prefix}@${rootDomain}`;
      const mailtoHref = `mailto:${email}`;
      const searchUrlQ   = buildSearchUrl(`"${email}"`, searchEngine);
      const searchUrlNoQ = buildSearchUrl(email, searchEngine);

      const tr = document.createElement('tr');
      tr.style.cssText = `background:${bg};cursor:pointer;`;

      const tdCb = document.createElement('td'); tdCb.style.cssText = cbStyle; tr.appendChild(tdCb);
      const tdNum = document.createElement('td'); tdNum.style.cssText = numStyle + 'width:44px;'; tdNum.textContent = '—'; tr.appendChild(tdNum);

      // Label cell — mailto link
      const tdLabel = document.createElement('td'); tdLabel.style.cssText = cellStyle;
      const aLabel = document.createElement('a');
      aLabel.href = mailtoHref; aLabel.textContent = email;
      aLabel.style.cssText = 'color:#33691e;text-decoration:none;font-weight:600;';
      aLabel.addEventListener('click', e => e.stopPropagation());
      tdLabel.appendChild(aLabel); tr.appendChild(tdLabel);

      // URL cell — mailto link + search buttons
      const tdUrl = document.createElement('td'); tdUrl.style.cssText = cellStyle + 'word-break:break-all;';
      const wrap = document.createElement('span'); wrap.style.cssText = 'display:flex;align-items:center;gap:6px;flex-wrap:wrap;';

      const aUrl = document.createElement('a');
      aUrl.href = mailtoHref; aUrl.textContent = email;
      aUrl.style.cssText = 'color:#33691e;text-decoration:none;font-size:0.9em;';
      aUrl.addEventListener('click', e => e.stopPropagation());
      wrap.appendChild(aUrl);

      // Search with quotes
      const btnQ = document.createElement('button');
      btnQ.textContent = '🔍 "quotes"'; btnQ.title = `Search "${email}" with quotes`;
      btnQ.style.cssText = 'background:#1b5e20;color:#fff;border:none;padding:3px 8px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:600;white-space:nowrap;';
      btnQ.addEventListener('click', e => {
        e.stopPropagation();
        browser.runtime.sendMessage({ action: 'openDirectTab', url: searchUrlQ, foreground: searchOpenMode === 'foreground' });
      });
      wrap.appendChild(btnQ);

      // Search without quotes
      const btnNoQ = document.createElement('button');
      btnNoQ.textContent = '🔍 no quotes'; btnNoQ.title = `Search ${email} without quotes`;
      btnNoQ.style.cssText = 'background:#388e3c;color:#fff;border:none;padding:3px 8px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:600;white-space:nowrap;';
      btnNoQ.addEventListener('click', e => {
        e.stopPropagation();
        browser.runtime.sendMessage({ action: 'openDirectTab', url: searchUrlNoQ, foreground: searchOpenMode === 'foreground' });
      });
      wrap.appendChild(btnNoQ);

      tdUrl.appendChild(wrap); tr.appendChild(tdUrl);

      // ↑ top
      const tdTop = document.createElement('td'); tdTop.style.cssText = 'padding:4px 6px;border:1px solid #ddd;text-align:center;width:32px;';
      const topBtn = document.createElement('button'); topBtn.textContent = '↑'; topBtn.title = 'Go to top of page';
      topBtn.style.cssText = 'background:transparent;border:1px solid #bbb;border-radius:3px;cursor:pointer;font-size:12px;color:#666;padding:2px 5px;';
      topBtn.addEventListener('click', e => { e.stopPropagation(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
      tdTop.appendChild(topBtn); tr.appendChild(tdTop);

      tr.addEventListener('click', () => { window.location.href = mailtoHref; });
      rows.push(tr);
    });

    return rows;
  }

  // ─── Clipboard + Email Domain Search rows ─────────────────────────────────────

  function buildClipboardEmailSearchRows(searchEngine, searchOpenMode) {
    const rows = [];

    const cellStyle = 'padding:6px 10px;border:1px solid #ddd;word-break:break-word;';
    const numStyle  = 'padding:6px 8px;border:1px solid #ddd;color:#888;font-size:0.85em;text-align:center;';
    const cbStyle   = 'padding:5px 8px;border:1px solid #ddd;text-align:center;width:36px;';
    const bg        = '#fce4ec';

    // Section header
    const hdrTr = document.createElement('tr');
    const hdrTd = document.createElement('td');
    hdrTd.colSpan = 5;
    hdrTd.style.cssText = 'padding:8px 12px;background:#880e4f;font-weight:bold;font-size:13px;color:#fff;border:1px solid #ddd;letter-spacing:0.3px;';
    hdrTd.textContent = '📋  Clipboard + Email Domain Search';
    hdrTr.appendChild(hdrTd); rows.push(hdrTr);

    const emailDomains = ['@gmail.com', '@yahoo.com', '@hotmail.com', '@live.com'];

    emailDomains.forEach(domain => {
      const makeClipRow = async () => {
        let clipText = '';
        try {
          clipText = (await navigator.clipboard.readText()).trim();
          if (!clipText) { alert('Clipboard is empty.'); return; }
        } catch (err) {
          alert('Could not read clipboard.');
          return;
        }
        return clipText;
      };

      const rowLabel   = `Search Clipboard + ${domain}`;
      const tr = document.createElement('tr'); tr.style.cssText = `background:${bg};cursor:pointer;`;

      const tdCb = document.createElement('td'); tdCb.style.cssText = cbStyle; tr.appendChild(tdCb);
      const tdNum = document.createElement('td'); tdNum.style.cssText = numStyle + 'width:44px;'; tdNum.textContent = '—'; tr.appendChild(tdNum);

      // Label cell — clickable
      const tdLabel = document.createElement('td'); tdLabel.style.cssText = cellStyle;
      const aLabel = document.createElement('a'); aLabel.href = '#'; aLabel.textContent = rowLabel;
      aLabel.style.cssText = 'color:#880e4f;text-decoration:none;font-weight:600;';

      // URL cell — same label as link + search buttons
      const tdUrl = document.createElement('td'); tdUrl.style.cssText = cellStyle + 'word-break:break-all;';
      const wrap = document.createElement('span'); wrap.style.cssText = 'display:flex;align-items:center;gap:6px;flex-wrap:wrap;';

      const aUrl = document.createElement('a'); aUrl.href = '#'; aUrl.textContent = rowLabel;
      aUrl.style.cssText = 'color:#ad1457;text-decoration:none;font-size:0.9em;font-weight:600;';

      // Search with quotes button
      const btnQ = document.createElement('button');
      btnQ.textContent = '🔍 "quotes"'; btnQ.title = `Search clipboard content + ${domain} with quotes`;
      btnQ.style.cssText = 'background:#880e4f;color:#fff;border:none;padding:3px 8px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:600;white-space:nowrap;';

      // Search without quotes button
      const btnNoQ = document.createElement('button');
      btnNoQ.textContent = '🔍 no quotes'; btnNoQ.title = `Search clipboard content + ${domain} without quotes`;
      btnNoQ.style.cssText = 'background:#ad1457;color:#fff;border:none;padding:3px 8px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:600;white-space:nowrap;';

      // Shared click handler
      const doSearch = async (withQuotes, e) => {
        if (e) { e.preventDefault(); e.stopPropagation(); }
        try {
          const clipText = (await navigator.clipboard.readText()).trim();
          if (!clipText) { alert('Clipboard is empty.'); return; }
          const query = withQuotes ? `"${clipText}${domain}"` : `${clipText}${domain}`;
          const url   = buildSearchUrl(query, searchEngine);
          browser.runtime.sendMessage({ action: 'openDirectTab', url, foreground: searchOpenMode === 'foreground' });
        } catch (err) {
          alert('Could not read clipboard.');
        }
      };

      aLabel.addEventListener('click',  e => doSearch(false, e));
      aUrl.addEventListener('click',    e => doSearch(false, e));
      btnQ.addEventListener('click',    e => doSearch(true, e));
      btnNoQ.addEventListener('click',  e => doSearch(false, e));

      wrap.appendChild(aUrl);
      wrap.appendChild(btnQ);
      wrap.appendChild(btnNoQ);

      tdLabel.appendChild(aLabel); tr.appendChild(tdLabel);
      tdUrl.appendChild(wrap); tr.appendChild(tdUrl);

      // ↑ top
      const tdTop = document.createElement('td'); tdTop.style.cssText = 'padding:4px 6px;border:1px solid #ddd;text-align:center;width:32px;';
      const topBtn = document.createElement('button'); topBtn.textContent = '↑'; topBtn.title = 'Go to top of page';
      topBtn.style.cssText = 'background:transparent;border:1px solid #bbb;border-radius:3px;cursor:pointer;font-size:12px;color:#666;padding:2px 5px;';
      topBtn.addEventListener('click', e => { e.stopPropagation(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
      tdTop.appendChild(topBtn); tr.appendChild(tdTop);

      tr.addEventListener('click', e => doSearch(false, e));
      rows.push(tr);
    });

    return rows;
  }

  // ─── Page Info rows (always last in table) ────────────────────────────────────

  function buildPageInfoRows(pageTitle, pageUrl) {
    const rows      = [];
    const cellStyle = 'padding:6px 10px;border:1px solid #ddd;word-break:break-word;';
    const numStyle  = 'padding:6px 8px;border:1px solid #ddd;color:#888;font-size:0.85em;text-align:center;';
    const cbStyle   = 'padding:5px 8px;border:1px solid #ddd;text-align:center;width:36px;';

    // Section header
    const hdrTr = document.createElement('tr');
    const hdrTd = document.createElement('td');
    hdrTd.colSpan = 5;
    hdrTd.style.cssText = 'padding:8px 12px;background:#37474f;font-weight:bold;font-size:13px;color:#fff;border:1px solid #ddd;letter-spacing:0.3px;';
    hdrTd.textContent = '🌐  Current Page';
    hdrTr.appendChild(hdrTd);
    rows.push(hdrTr);

    // Helper: make an info row with optional copy button
    function makeInfoRow(labelText, valueText, valueHref, copyValue) {
      const tr = document.createElement('tr');
      tr.style.cssText = 'background:#eceff1;';

      // No checkbox for page-info rows — just an empty placeholder cell
      const tdCb = document.createElement('td');
      tdCb.style.cssText = cbStyle;
      tr.appendChild(tdCb);

      // # — dash
      const tdNum = document.createElement('td');
      tdNum.style.cssText = numStyle + 'width:44px;';
      tdNum.textContent = '—';
      tr.appendChild(tdNum);

      // Label cell
      const tdLabel = document.createElement('td');
      tdLabel.style.cssText = cellStyle + 'font-weight:bold;color:#333;font-size:0.9em;white-space:nowrap;';
      tdLabel.textContent = labelText;
      tr.appendChild(tdLabel);

      // Value cell — with optional link and copy button
      const tdVal = document.createElement('td');
      tdVal.style.cssText = cellStyle + 'word-break:break-all;';
      const wrap = document.createElement('span');
      wrap.style.cssText = 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;';

      if (valueHref) {
        const a = document.createElement('a');
        a.href = valueHref; a.title = valueHref; a.textContent = valueText;
        a.style.cssText = 'color:#006621;text-decoration:none;font-size:0.88em;';
        a.target = '_blank'; a.rel = 'noopener noreferrer';
        wrap.appendChild(a);
      } else {
        const span = document.createElement('span');
        span.textContent = valueText;
        span.style.cssText = 'color:#333;font-size:0.92em;flex:1;';
        wrap.appendChild(span);
      }

      if (copyValue) {
        const copyBtn = document.createElement('button');
        copyBtn.textContent = '📋 Copy';
        copyBtn.title = 'Copy: ' + copyValue;
        copyBtn.style.cssText = 'background:#37474f;color:#fff;border:none;padding:3px 9px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:600;white-space:nowrap;flex-shrink:0;';
        copyBtn.addEventListener('click', e => {
          e.stopPropagation();
          navigator.clipboard.writeText(copyValue).then(() => {
            copyBtn.textContent = '✓ Copied!'; copyBtn.style.background = '#2e7d32';
            setTimeout(() => { copyBtn.textContent = '📋 Copy'; copyBtn.style.background = '#37474f'; }, 1800);
          }).catch(() => {
            copyBtn.textContent = '✗ Failed';
            setTimeout(() => { copyBtn.textContent = '📋 Copy'; }, 1800);
          });
        });
        wrap.appendChild(copyBtn);
      }

      tdVal.appendChild(wrap);
      tr.appendChild(tdVal);

      // ↑ top button
      const tdTop = document.createElement('td');
      tdTop.style.cssText = 'padding:4px 6px;border:1px solid #ddd;text-align:center;width:32px;';
      const topBtn = document.createElement('button');
      topBtn.textContent = '↑'; topBtn.title = 'Go to top of page';
      topBtn.style.cssText = 'background:transparent;border:1px solid #bbb;border-radius:3px;cursor:pointer;font-size:12px;color:#666;padding:2px 5px;';
      topBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
      tdTop.appendChild(topBtn); tr.appendChild(tdTop);

      rows.push(tr);
    }

    makeInfoRow('📄 Page Title', pageTitle || '(no title)', null, pageTitle || '');
    makeInfoRow('🔗 Page URL',   pageUrl,                   pageUrl, pageUrl);

    return rows;
  }

  // ─── Domain Search rows ───────────────────────────────────────────────────────

  function buildDomainSearchRows(pageUrl, searchEngine, searchOpenMode) {
    const rows = [];
    if (!pageUrl) return rows;

    let fullHostname = '';
    try {
      fullHostname = new URL(pageUrl).hostname;
    } catch (e) { return rows; }
    if (!fullHostname) return rows;

    // Strip leading www.
    const cleanHostname = fullHostname.replace(/^www\./, '');

    // Determine root domain vs subdomain
    // e.g. "mark.wayne.yahoo.com" → rootDomain="yahoo.com", hasSubdomain=true
    // e.g. "aepm.org" → rootDomain="aepm.org", hasSubdomain=false
    const parts = cleanHostname.split('.');
    const rootDomain   = parts.length > 2 ? parts.slice(-2).join('.') : cleanHostname;
    const hasSubdomain = parts.length > 2;

    const bg        = '#fafafa';
    const cellStyle = 'padding:6px 10px;border:1px solid #ddd;word-break:break-word;';
    const numStyle  = 'padding:6px 8px;border:1px solid #ddd;color:#888;font-size:0.85em;text-align:center;';
    const cbStyle   = 'padding:5px 8px;border:1px solid #ddd;text-align:center;width:36px;';

    // Helper: build a search query set for a given domain string
    function makeSearchSet(domain, sectionLabel, sectionColor) {
      const atDomain = '@' + domain;

      const hdrTr = document.createElement('tr');
      const hdrTd = document.createElement('td');
      hdrTd.colSpan = 5;
      hdrTd.style.cssText = `padding:8px 12px;background:${sectionColor};font-weight:bold;font-size:13px;color:#fff;border:1px solid #ddd;letter-spacing:0.3px;`;
      hdrTd.textContent = sectionLabel;
      hdrTr.appendChild(hdrTd);
      rows.push(hdrTr);

      const searches = [
        { label: `Search ${domain}`,                   query: domain },
        { label: `Search ${atDomain} emails`,          query: `${atDomain} emails` },
        { label: `Search ${atDomain} staff`,           query: `${atDomain} staff` },
        { label: `Search ${atDomain} board`,           query: `${atDomain} board` },
        { label: `Search ${atDomain} team`,            query: `${atDomain} team` },
        { label: `Search ${atDomain} linkedin`,        query: `${atDomain} linkedin` },
        { label: `Search ${atDomain} phone number`,    query: `${atDomain} phone number` },
        { label: `Search ${atDomain} Media Contacts`,  query: `${atDomain} Media Contacts` },
      ];

      searches.forEach(({ label, query }) => {
        const searchUrl = buildSearchUrl(query, searchEngine);
        const tr = document.createElement('tr');
        tr.style.cssText = `background:${bg};cursor:pointer;`;

        const tdCb = document.createElement('td'); tdCb.style.cssText = cbStyle; tr.appendChild(tdCb);
        const tdNum = document.createElement('td'); tdNum.style.cssText = numStyle + 'width:44px;'; tdNum.textContent = '—'; tr.appendChild(tdNum);

        const tdLabel = document.createElement('td'); tdLabel.style.cssText = cellStyle;
        const aLabel = document.createElement('a'); aLabel.href = searchUrl; aLabel.textContent = label;
        aLabel.style.cssText = 'color:#4a148c;text-decoration:none;font-weight:600;';
        aLabel.addEventListener('click', e => {
          e.preventDefault(); e.stopPropagation();
          browser.runtime.sendMessage({ action: 'openDirectTab', url: searchUrl, foreground: searchOpenMode === 'foreground' });
        });
        tdLabel.appendChild(aLabel); tr.appendChild(tdLabel);

        const tdUrl = document.createElement('td'); tdUrl.style.cssText = cellStyle + 'word-break:break-all;';
        const aUrl = document.createElement('a'); aUrl.href = searchUrl; aUrl.textContent = searchUrl;
        aUrl.style.cssText = 'color:#6a1b9a;text-decoration:none;font-size:0.82em;';
        aUrl.addEventListener('click', e => {
          e.preventDefault(); e.stopPropagation();
          browser.runtime.sendMessage({ action: 'openDirectTab', url: searchUrl, foreground: searchOpenMode === 'foreground' });
        });
        tdUrl.appendChild(aUrl); tr.appendChild(tdUrl);

        const tdTop = document.createElement('td'); tdTop.style.cssText = 'padding:4px 6px;border:1px solid #ddd;text-align:center;width:32px;';
        const topBtn = document.createElement('button'); topBtn.textContent = '↑'; topBtn.title = 'Go to top of page';
        topBtn.style.cssText = 'background:transparent;border:1px solid #bbb;border-radius:3px;cursor:pointer;font-size:12px;color:#666;padding:2px 5px;';
        topBtn.addEventListener('click', e => { e.stopPropagation(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
        tdTop.appendChild(topBtn); tr.appendChild(tdTop);

        tr.addEventListener('click', () => {
          browser.runtime.sendMessage({ action: 'openDirectTab', url: searchUrl, foreground: searchOpenMode === 'foreground' });
        });
        rows.push(tr);
      });
    }

    // Always generate rows for root domain
    makeSearchSet(rootDomain, `🔎  Domain Search — ${rootDomain}`, '#4a148c');

    // If subdomain present, also generate rows for full subdomain hostname
    if (hasSubdomain) {
      makeSearchSet(cleanHostname, `🔎  Subdomain Search — ${cleanHostname}`, '#6a1b9a');
    }

    // "Search Clipboard Content" row — appears once after all domain rows
    const clipBg = '#fafafa';
    const clipTr = document.createElement('tr');
    clipTr.style.cssText = `background:${clipBg};cursor:pointer;`;

    const clipCb = document.createElement('td'); clipCb.style.cssText = cbStyle; clipTr.appendChild(clipCb);
    const clipNum = document.createElement('td'); clipNum.style.cssText = numStyle + 'width:44px;'; clipNum.textContent = '—'; clipTr.appendChild(clipNum);

    // Label cell
    const clipLabel = document.createElement('td'); clipLabel.style.cssText = cellStyle;
    const clipA = document.createElement('a'); clipA.href = '#'; clipA.textContent = 'Search Clipboard Content';
    clipA.style.cssText = 'color:#4a148c;text-decoration:none;font-weight:600;';
    const doClipSearch = async (e) => {
      if (e) { e.preventDefault(); e.stopPropagation(); }
      try {
        const text = await navigator.clipboard.readText();
        if (!text.trim()) { alert('Clipboard is empty.'); return; }
        const url = buildSearchUrl(text.trim(), searchEngine);
        browser.runtime.sendMessage({ action: 'openDirectTab', url, foreground: searchOpenMode === 'foreground' });
      } catch (err) {
        alert('Could not read clipboard. Please copy something first and ensure clipboard access is allowed.');
      }
    };
    clipA.addEventListener('click', doClipSearch);
    clipLabel.appendChild(clipA); clipTr.appendChild(clipLabel);

    // URL cell — also a clickable link that does the same clipboard search
    const clipUrl = document.createElement('td'); clipUrl.style.cssText = cellStyle + 'word-break:break-all;';
    const clipUrlA = document.createElement('a'); clipUrlA.href = '#'; clipUrlA.textContent = 'Search Clipboard Content';
    clipUrlA.style.cssText = 'color:#6a1b9a;text-decoration:none;font-size:0.9em;font-weight:600;';
    clipUrlA.addEventListener('click', doClipSearch);
    clipUrl.appendChild(clipUrlA); clipTr.appendChild(clipUrl);

    const clipTop = document.createElement('td'); clipTop.style.cssText = 'padding:4px 6px;border:1px solid #ddd;text-align:center;width:32px;';
    const clipTopBtn = document.createElement('button'); clipTopBtn.textContent = '↑'; clipTopBtn.title = 'Go to top';
    clipTopBtn.style.cssText = 'background:transparent;border:1px solid #bbb;border-radius:3px;cursor:pointer;font-size:12px;color:#666;padding:2px 5px;';
    clipTopBtn.addEventListener('click', e => { e.stopPropagation(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
    clipTop.appendChild(clipTopBtn); clipTr.appendChild(clipTop);

    clipTr.addEventListener('click', doClipSearch);
    rows.push(clipTr);
    return rows;
  }

  // ─── Build Table ─────────────────────────────────────────────────────────────

  function buildTable(regularUrls, special, settings, isAllMode, pageTitle, pageUrl) {
    const {
      highlightWords, matchMode, highlightColor, fontSize,
      linkOpenMode, newTabMode, highlightTabMode,
      autoOpenHighlighted, confirmHighlighted, confirmThreshold,
      showHighlightedSection, openUniqueOnly,
      searchEngine, searchOpenMode
    } = settings;

    const hlWordList = (highlightWords || '')
      .split('\n').map(w => w.trim().toLowerCase()).filter(Boolean);

    let sortCol     = settings.sortCol !== undefined ? settings.sortCol : 0;
    let sortAsc     = settings.sortAsc !== undefined ? settings.sortAsc : true;
    let quickFilter = '';
    // Toggle state for "Check Highlighted Only" button
    let highlightedOnlyMode = false;

    const checkedMap = new Map();
    regularUrls.forEach(item => checkedMap.set(item.text + '|||' + item.url, true));

    // ── Wrapper ──────────────────────────────────────────────────────────────
    const wrapper = document.createElement('div');
    wrapper.id = CONTAINER_ID;
    wrapper.style.cssText = `
      all:initial;display:block;font-family:Arial,sans-serif;font-size:${fontSize}px;
      color:#111;background:#fff;border:2.5px solid #3a7bd5;border-radius:10px;
      padding:18px;margin:0 0 20px 0;box-sizing:border-box;width:100%;
      position:relative;z-index:999999;
    `;

    // ── Title ────────────────────────────────────────────────────────────────
    const titleBar = document.createElement('div');
    titleBar.style.cssText = 'display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px;';
    const title = document.createElement('div');
    title.style.cssText = 'font-weight:bold;font-size:1.15em;color:#3a7bd5;';

    function updateTitle(visibleCount) {
      const total = regularUrls.length;
      const ct    = visibleCount !== undefined ? visibleCount : total;
      const diff  = ct !== total ? ` (filtered from ${total})` : '';
      const badge = isAllMode ? ' <span style="background:#e67e22;color:#fff;font-size:11px;padding:1px 7px;border-radius:10px;vertical-align:middle;">ALL</span>' : '';
      title.innerHTML = `🔗 URL Extractor Pro — ${ct} URL(s)${diff}${badge}`;
    }
    updateTitle();
    titleBar.appendChild(title);

    const fontCtrl = document.createElement('div');
    fontCtrl.style.cssText = 'display:flex;align-items:center;gap:6px;font-size:13px;color:#555;';
    fontCtrl.innerHTML = `
      <span>Font:</span>
      <button id="ue-font-down" style="${bs()}">A−</button>
      <span id="ue-font-size-display" style="min-width:34px;text-align:center;">${fontSize}px</span>
      <button id="ue-font-up" style="${bs()}">A+</button>
    `;
    titleBar.appendChild(fontCtrl);
    wrapper.appendChild(titleBar);

    // ── Quick filter ─────────────────────────────────────────────────────────
    const filterRow = document.createElement('div');
    filterRow.style.cssText = 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:10px;';
    filterRow.innerHTML = `
      <span style="font-size:13px;color:#555;">Quick Filter:</span>
      <input id="ue-filter-input" type="text" placeholder="Filter table…"
        style="padding:5px 9px;border:1px solid #ccc;border-radius:5px;font-size:13px;flex:1;min-width:160px;" />
      <button id="ue-filter-btn" style="${bs('#3a7bd5','#fff')}">Apply</button>
      <button id="ue-clear-filter-btn" style="${bs()}">Clear</button>
    `;
    wrapper.appendChild(filterRow);

    // ── Buttons ──────────────────────────────────────────────────────────────
    const btnRow = document.createElement('div');
    btnRow.style.cssText = 'display:flex;align-items:center;gap:7px;margin-bottom:10px;flex-wrap:wrap;';
    btnRow.innerHTML = `
      <button id="ue-extract-all"         style="${bs('#009688','#fff')}">🔄 Extract All URLs</button>
      <button id="ue-check-all"           style="${bs('#607d8b','#fff')}">☑ Check All</button>
      <button id="ue-uncheck-all"         style="${bs('#90a4ae','#fff')}">☐ Uncheck All</button>
      <button id="ue-check-highlighted"   style="${bs('#e67e22','#fff')}">⭐ Check Highlighted Only</button>
      <button id="ue-open-checked"        style="${bs('#1565c0','#fff')}">🔗 Open Checked</button>
      <button id="ue-open-highlighted"    style="${bs('#f57f17','#fff')}">⭐ Open Highlighted</button>
      <button id="ue-export-btn"          style="${bs('#27ae60','#fff')}">📥 Export CSV</button>
      <button id="ue-copy-btn"            style="${bs('#8e44ad','#fff')}">📋 Copy Table</button>
      <button id="ue-newtab-btn"          style="${bs('#e67e22','#fff')}">🗂 New Tab</button>
      <button id="ue-goto-bottom-btn"     style="${bs('#455a64','#fff')}">⬇ Go to Table Bottom</button>
      <button id="ue-settings-btn"        style="${bs('#546e7a','#fff')}">⚙ Settings</button>
      <button id="ue-close-btn"           style="${bs('#e74c3c','#fff')}">✕ Close</button>
    `;
    wrapper.appendChild(btnRow);

    // ── Table ────────────────────────────────────────────────────────────────
    const tableWrap = document.createElement('div');
    tableWrap.style.cssText = 'overflow-x:auto;';
    const table = document.createElement('table');
    table.id = 'ue-table';
    table.style.cssText = `border-collapse:collapse;width:100%;font-size:${fontSize}px;`;

    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    // 5 columns: checkbox, #, text, url, ↑
    [['☑','36px',false],['#','44px',false],['Link Text ▲','34%',true],['URL','',true],['↑','32px',false]]
      .forEach(([label, width, sortable], i) => {
        const th = document.createElement('th');
        th.textContent = label;
        th.style.cssText = `
          background:#3a7bd5;color:#fff;padding:9px 10px;text-align:left;
          border:1px solid #2563b5;user-select:none;white-space:nowrap;
          cursor:${sortable ? 'pointer' : 'default'};
          ${width ? (width.includes('%') ? `width:${width};` : `width:${width};text-align:center;`) : ''}
        `;
        if (i === 4) th.style.cssText += 'text-align:center;'; // ↑ col
        if (sortable) {
          th.addEventListener('click', () => {
            const ci = i - 2;
            if (sortCol === ci) sortAsc = !sortAsc;
            else { sortCol = ci; sortAsc = true; }
            updateHeaderArrows();
            renderRows(getFilteredList());
          });
        }
        headerRow.appendChild(th);
      });
    thead.appendChild(headerRow);
    table.appendChild(thead);

    const tbody = document.createElement('tbody');
    table.appendChild(tbody);
    tableWrap.appendChild(table);
    wrapper.appendChild(tableWrap);

    const goTopDiv = document.createElement('div');
    goTopDiv.style.cssText = 'margin-top:12px;display:flex;justify-content:space-between;align-items:center;';
    goTopDiv.innerHTML = `
      <a href="#" id="ue-go-top" style="color:#3a7bd5;font-size:13px;text-decoration:none;">▲ Go to Top of Page</a>
      <button id="ue-goto-table-top-btn" style="background:#3a7bd5;color:#fff;border:none;padding:6px 14px;border-radius:5px;cursor:pointer;font-size:13px;font-weight:600;">⬆ Go to Start of Table</button>
    `;
    wrapper.appendChild(goTopDiv);
    // Bottom anchor — used by "Go to Table Bottom" button
    const tableBottomAnchor = document.createElement('div');
    tableBottomAnchor.id = 'ue-table-bottom-anchor';
    wrapper.appendChild(tableBottomAnchor);
    wrapper.appendChild(document.createElement('br'));
    wrapper.appendChild(document.createElement('br'));

    // ── Helpers ──────────────────────────────────────────────────────────────

    function isHighlighted(item) {
      return hlWordList.length > 0 && wordMatches(item, hlWordList, matchMode);
    }

    function getFilteredList() {
      let list = [...regularUrls];
      if (quickFilter) {
        const qf = quickFilter.toLowerCase();
        list = list.filter(item =>
          item.text.toLowerCase().includes(qf) ||
          item.url.toLowerCase().includes(qf) ||
          (item.rawHref || '').toLowerCase().includes(qf)
        );
      }
      return list;
    }

    function updateHeaderArrows() {
      const ths = table.querySelectorAll('thead th');
      ths[2].textContent = 'Link Text ' + (sortCol === 0 ? (sortAsc ? '▲' : '▼') : '');
      ths[3].textContent = 'URL '       + (sortCol === 1 ? (sortAsc ? '▲' : '▼') : '');
    }

    let currentSorted = [];
    const linkTarget  = linkOpenMode === 'background' ? '_blank' : '_blank'; // always _blank, foreground handled below

    function renderRows(list) {
      list = [...list].sort((a, b) => {
        const va = sortCol === 0 ? a.text : a.url;
        const vb = sortCol === 0 ? b.text : b.url;
        return sortAsc ? va.localeCompare(vb) : vb.localeCompare(va);
      });
      currentSorted = list;

      tbody.innerHTML = '';

      // ── Optional highlighted section at top ─────────────────────────────
      if (showHighlightedSection && hlWordList.length > 0) {
        const hlList = list.filter(isHighlighted);
        if (hlList.length > 0) {
          const secTr = document.createElement('tr');
          const secTd = document.createElement('td');
          secTd.colSpan = 5;
          secTd.style.cssText = `padding:8px 12px;background:#7b1fa2;font-weight:bold;font-size:13px;color:#fff;border:1px solid #ddd;letter-spacing:0.3px;`;
          secTd.textContent = `⭐  Highlighted URLs (${hlList.length})`;
          secTr.appendChild(secTd); tbody.appendChild(secTr);
          hlList.forEach(item => appendRegularRow(item, list.indexOf(item)));
          // Divider
          const divTr = document.createElement('tr');
          const divTd = document.createElement('td');
          divTd.colSpan = 5;
          divTd.style.cssText = 'padding:6px 12px;background:#f0f4f8;font-weight:bold;font-size:12px;color:#555;border:1px solid #ddd;letter-spacing:0.3px;';
          divTd.textContent = `─── All URLs (${list.length}) ───`;
          divTr.appendChild(divTd); tbody.appendChild(divTr);
        }
      }

      list.forEach((item, idx) => appendRegularRow(item, idx));

      // Always append special rows
      const specialRows = buildSpecialRows(special, highlightColor, hlWordList, matchMode, checkedMap, searchEngine, searchOpenMode);
      specialRows.forEach(tr => tbody.appendChild(tr));

      // Domain search section
      const domainRows = buildDomainSearchRows(pageUrl, searchEngine, searchOpenMode);
      domainRows.forEach(tr => tbody.appendChild(tr));

      // Dummy email rows (info@domain, contactus@domain)
      const dummyEmailRows = buildDummyEmailRows(pageUrl, searchEngine, searchOpenMode);
      dummyEmailRows.forEach(tr => tbody.appendChild(tr));

      // Clipboard + email domain search rows
      const clipEmailRows = buildClipboardEmailSearchRows(searchEngine, searchOpenMode);
      clipEmailRows.forEach(tr => tbody.appendChild(tr));

      // Current page info (always last)
      const pageInfoRows = buildPageInfoRows(pageTitle, pageUrl);
      pageInfoRows.forEach(tr => tbody.appendChild(tr));

      updateTitle(list.length);
    }

    function appendRegularRow(item, idx) {
      const key        = item.text + '|||' + item.url;
      const highlighted = isHighlighted(item);
      const checked    = checkedMap.get(key) !== false;

      const tr = document.createElement('tr');
      tr.style.cssText = `background:${highlighted ? highlightColor : (idx % 2 === 0 ? '#f9f9f9' : '#fff')};cursor:pointer;`;

      // Checkbox
      const tdCb = document.createElement('td');
      tdCb.style.cssText = 'padding:5px 8px;border:1px solid #ddd;text-align:center;width:36px;';
      const cb = document.createElement('input');
      cb.type = 'checkbox'; cb.checked = checked;
      cb.style.cssText = 'width:15px;height:15px;cursor:pointer;';
      cb.addEventListener('change', e => { e.stopPropagation(); checkedMap.set(key, cb.checked); });
      tdCb.appendChild(cb); tr.appendChild(tdCb);

      // Number
      const tdNum = document.createElement('td');
      tdNum.textContent = idx + 1;
      tdNum.style.cssText = 'padding:6px 8px;border:1px solid #ddd;color:#888;font-size:0.85em;text-align:center;width:44px;';
      tr.appendChild(tdNum);

      // Link text
      const tdText = document.createElement('td');
      tdText.style.cssText = 'padding:6px 10px;border:1px solid #ddd;word-break:break-word;';
      const aText = document.createElement('a');
      aText.href = item.url; aText.title = item.url; aText.textContent = item.text;
      aText.style.cssText = item.noTitle
        ? 'color:#999;text-decoration:none;font-style:italic;'
        : 'color:#1a0dab;text-decoration:none;';
      aText.target = '_blank'; aText.rel = 'noopener noreferrer';
      // For background mode, we open via message; for foreground _blank is fine
      if (linkOpenMode === 'background') {
        aText.addEventListener('click', e => {
          e.preventDefault(); e.stopPropagation();
          browser.runtime.sendMessage({ action: 'openDirectTab', url: item.url, foreground: false });
        });
      } else {
        aText.addEventListener('click', e => e.stopPropagation());
      }
      tdText.appendChild(aText); tr.appendChild(tdText);

      // URL
      const tdUrl = document.createElement('td');
      tdUrl.style.cssText = 'padding:6px 10px;border:1px solid #ddd;word-break:break-all;';
      const aUrl = document.createElement('a');
      aUrl.href = item.url; aUrl.title = item.url; aUrl.textContent = item.url;
      aUrl.style.cssText = 'color:#006621;text-decoration:none;font-size:0.88em;';
      aUrl.target = '_blank'; aUrl.rel = 'noopener noreferrer';
      if (linkOpenMode === 'background') {
        aUrl.addEventListener('click', e => {
          e.preventDefault(); e.stopPropagation();
          browser.runtime.sendMessage({ action: 'openDirectTab', url: item.url, foreground: false });
        });
      } else {
        aUrl.addEventListener('click', e => e.stopPropagation());
      }
      tdUrl.appendChild(aUrl); tr.appendChild(tdUrl);

      // ↑ Go to top button
      const tdTop = document.createElement('td');
      tdTop.style.cssText = 'padding:4px 6px;border:1px solid #ddd;text-align:center;width:32px;';
      const topBtn = document.createElement('button');
      topBtn.textContent = '↑';
      topBtn.title = 'Go to top of page';
      topBtn.style.cssText = `background:transparent;border:1px solid #bbb;border-radius:3px;cursor:pointer;font-size:12px;color:#666;padding:2px 5px;`;
      topBtn.addEventListener('click', e => { e.stopPropagation(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
      tdTop.appendChild(topBtn); tr.appendChild(tdTop);

      tr.addEventListener('click', () => { cb.checked = !cb.checked; checkedMap.set(key, cb.checked); });
      tbody.appendChild(tr);
    }

    // ── Wire Events ──────────────────────────────────────────────────────────

    function wireEvents() {
      wrapper.querySelector('#ue-font-down').addEventListener('click', async () => {
        const cur = parseInt(table.style.fontSize) || fontSize;
        const ns  = Math.max(8, cur - 1);
        table.style.fontSize = ns + 'px';
        wrapper.querySelector('#ue-font-size-display').textContent = ns + 'px';
        await browser.storage.local.set({ fontSize: ns });
      });
      wrapper.querySelector('#ue-font-up').addEventListener('click', async () => {
        const cur = parseInt(table.style.fontSize) || fontSize;
        const ns  = cur + 1;
        table.style.fontSize = ns + 'px';
        wrapper.querySelector('#ue-font-size-display').textContent = ns + 'px';
        await browser.storage.local.set({ fontSize: ns });
      });

      function applyFilter() {
        quickFilter = wrapper.querySelector('#ue-filter-input').value.trim();
        renderRows(getFilteredList());
      }
      wrapper.querySelector('#ue-filter-btn').addEventListener('click', applyFilter);
      wrapper.querySelector('#ue-filter-input').addEventListener('keydown', e => { if (e.key === 'Enter') applyFilter(); });
      wrapper.querySelector('#ue-clear-filter-btn').addEventListener('click', () => {
        wrapper.querySelector('#ue-filter-input').value = ''; quickFilter = ''; renderRows(getFilteredList());
      });

      wrapper.querySelector('#ue-extract-all').addEventListener('click', () => { run(true); });

      wrapper.querySelector('#ue-check-all').addEventListener('click', () => {
        highlightedOnlyMode = false;
        const btn = wrapper.querySelector('#ue-check-highlighted');
        btn.textContent = '⭐ Check Highlighted Only';
        btn.style.background = '#e67e22';
        currentSorted.forEach(item => checkedMap.set(item.text + '|||' + item.url, true));
        renderRows(getFilteredList());
      });
      wrapper.querySelector('#ue-uncheck-all').addEventListener('click', () => {
        highlightedOnlyMode = false;
        const btn = wrapper.querySelector('#ue-check-highlighted');
        btn.textContent = '⭐ Check Highlighted Only';
        btn.style.background = '#e67e22';
        currentSorted.forEach(item => checkedMap.set(item.text + '|||' + item.url, false));
        renderRows(getFilteredList());
      });

      // Toggle: Check Highlighted Only ↔ Uncheck Highlighted / Check All
      wrapper.querySelector('#ue-check-highlighted').addEventListener('click', () => {
        const btn = wrapper.querySelector('#ue-check-highlighted');
        if (!highlightedOnlyMode) {
          // Mode ON: check only highlighted, uncheck rest
          highlightedOnlyMode = true;
          currentSorted.forEach(item => {
            const key = item.text + '|||' + item.url;
            checkedMap.set(key, isHighlighted(item));
          });
          btn.textContent = '☑ Check All (undo)';
          btn.style.background = '#7b1fa2';
        } else {
          // Mode OFF: restore all checked
          highlightedOnlyMode = false;
          currentSorted.forEach(item => checkedMap.set(item.text + '|||' + item.url, true));
          btn.textContent = '⭐ Check Highlighted Only';
          btn.style.background = '#e67e22';
        }
        renderRows(getFilteredList());
      });

      wrapper.querySelector('#ue-open-checked').addEventListener('click', () => {
        let toOpen = currentSorted.filter(item => checkedMap.get(item.text + '|||' + item.url) !== false);
        if (openUniqueOnly) toOpen = uniqueByUrl(toOpen);
        if (!toOpen.length) { alert('No checked URLs to open.'); return; }
        openUrls(toOpen, newTabMode === 'foreground');
      });

      wrapper.querySelector('#ue-open-highlighted').addEventListener('click', async () => {
        let toOpen = currentSorted.filter(isHighlighted);
        toOpen = uniqueByUrl(toOpen); // highlighted always deduped by URL
        if (!toOpen.length) { alert('No highlighted URLs. Set highlight words in Settings.'); return; }
        const threshold = confirmThreshold !== undefined ? confirmThreshold : 5;
        if (confirmHighlighted && toOpen.length > threshold) {
          const ok = await showConfirmDialog({
            title: '⭐ Open Highlighted URLs',
            message: `You are about to open <strong>${toOpen.length} highlighted URL(s)</strong> in new tabs.<br><br>Do you want to continue?`,
            confirmLabel: `Open ${toOpen.length} tabs`,
            cancelLabel: 'Cancel'
          });
          if (!ok) return;
        }
        openUrls(toOpen, highlightTabMode === 'foreground');
      });

      wrapper.querySelector('#ue-export-btn').addEventListener('click', () => {
        const rows = [['Text','URL'], ...currentSorted.map(i => [escapeCsv(i.text), escapeCsv(i.url)])];
        downloadFile(rows.map(r => r.join(',')).join('\n'), 'url-extractor-' + timestamp() + '.csv', 'text/csv');
      });

      wrapper.querySelector('#ue-copy-btn').addEventListener('click', () => {
        const text = ['Text\tURL', ...currentSorted.map(i => `${i.text}\t${i.url}`)].join('\n');
        navigator.clipboard.writeText(text).then(() => {
          const btn = wrapper.querySelector('#ue-copy-btn');
          btn.textContent = '✓ Copied!';
          setTimeout(() => { btn.textContent = '📋 Copy Table'; }, 1500);
        });
      });

      wrapper.querySelector('#ue-newtab-btn').addEventListener('click', () => {
        browser.runtime.sendMessage({
          action: 'openNewTab', urls: currentSorted, special,
          settings: { ...settings, _pageTitle: document.title, _pageUrl: location.href },
          foreground: newTabMode === 'foreground'
        });
      });

      wrapper.querySelector('#ue-settings-btn').addEventListener('click', () => {
        browser.runtime.sendMessage({ action: 'openSettings' });
      });

      wrapper.querySelector('#ue-close-btn').addEventListener('click', () => {
        document.getElementById(SPACER_ID)?.remove();
        wrapper.remove();
        document.getElementById('ue-goto-table-fab')?.remove();
      });

      wrapper.querySelector('#ue-go-top').addEventListener('click', e => {
        e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' });
      });

      // Go to Table Bottom — scrolls to bottom anchor at end of table
      wrapper.querySelector('#ue-goto-bottom-btn').addEventListener('click', () => {
        const anchor = document.getElementById('ue-table-bottom-anchor');
        if (anchor) anchor.scrollIntoView({ behavior: 'smooth', block: 'end' });
      });

      // Go to Start of Table — scrolls back up to the table header
      wrapper.querySelector('#ue-goto-table-top-btn').addEventListener('click', () => {
        wrapper.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    }

    renderRows(regularUrls);

    return {
      wrapper, wireEvents,
      getHighlightedUrls: () => uniqueByUrl(regularUrls.filter(isHighlighted))
    };
  }

  // ─── Main ────────────────────────────────────────────────────────────────────

  async function run(ignoreFilter) {
    const settings = await getSettings();
    const { regular, special } = extractAllURLs(settings.filterWords, settings.matchMode, !!ignoreFilter, settings.eventHuntersEnabled);

    document.getElementById(CONTAINER_ID)?.remove();
    document.getElementById(SPACER_ID)?.remove();
    document.getElementById('ue-goto-table-fab')?.remove();

    const { wrapper, wireEvents, getHighlightedUrls } = buildTable(regular, special, settings, !!ignoreFilter, document.title, location.href);

    const spacer = document.createElement('div');
    spacer.id = SPACER_ID;
    spacer.style.cssText = 'height:120px;display:block;';

    const target = document.body || document.documentElement;
    target.appendChild(spacer);
    target.appendChild(wrapper);
    wireEvents();

    // Floating "go to table" button
    createGoToTableBtn(CONTAINER_ID);

    if (settings.scrollToTable !== false) {
      setTimeout(() => { wrapper.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 100);
    }

    if (settings.autoOpenHighlighted) {
      const highlighted = getHighlightedUrls();
      if (highlighted.length > 0) {
        const threshold = settings.confirmThreshold !== undefined ? settings.confirmThreshold : 5;
        const proceed = async () => {
          if (settings.confirmHighlighted && highlighted.length > threshold) {
            return await showConfirmDialog({
              title: '⭐ Auto-Open Highlighted URLs',
              message: `<strong>${highlighted.length} highlighted URL(s)</strong> found — open in new tabs?`,
              confirmLabel: `Open ${highlighted.length} tabs`,
              cancelLabel: 'Cancel'
            });
          }
          return true;
        };
        proceed().then(ok => {
          if (!ok) return;
          highlighted.forEach((item, i) => {
            browser.runtime.sendMessage({
              action: 'openDirectTab', url: item.url,
              foreground: settings.highlightTabMode === 'foreground' && i === 0
            });
          });
        });
      }
    }
  }

  browser.runtime.onMessage.addListener((message) => {
    if (message.action === 'extractURLs') { run(false); }
    return false;
  });

})();
