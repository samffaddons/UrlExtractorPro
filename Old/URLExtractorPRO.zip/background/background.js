// URL Extractor Pro v9 - Firefox Background Script

browser.commands.onCommand.addListener(async (command) => {
  if (command === 'extract-urls') {
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    if (tabs[0]) browser.tabs.sendMessage(tabs[0].id, { action: 'extractURLs' });
  }
});

browser.runtime.onMessage.addListener(async (message, sender) => {

  if (message.action === 'openNewTab') {
    const tab = await browser.tabs.create({
      url: browser.runtime.getURL('newtab/newtab.html'),
      active: message.foreground !== false
    });
    await browser.storage.local.set({
      [`newTabData_${tab.id}`]: {
        urls: message.urls,
        special: message.special || {},
        settings: message.settings
      }
    });
    return { tabId: tab.id };
  }

  if (message.action === 'openDirectTab') {
    browser.tabs.create({ url: message.url, active: !!message.foreground });
    return;
  }

  if (message.action === 'openSettings') {
    browser.tabs.create({ url: browser.runtime.getURL('options/options.html') });
    return;
  }

  if (message.action === 'getNewTabData') {
    const tabId = sender.tab ? sender.tab.id : null;
    if (tabId) {
      const key  = `newTabData_${tabId}`;
      const data = await browser.storage.local.get(key);
      await browser.storage.local.remove(key);
      return data[key] || null;
    }
    return null;
  }
});
