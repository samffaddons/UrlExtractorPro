/* URL Extractor Pro v9 — Settings Page */

const DEFAULTS = {
  filterWords:            '',
  highlightWords:         '',
  matchMode:              'both',
  highlightColor:         '#ffff00',
  fontSize:               16,
  linkOpenMode:           'foreground',
  newTabMode:             'foreground',
  highlightTabMode:       'foreground',
  openOnlyHighlighted:    false,
  autoOpenHighlighted:    false,
  confirmHighlighted:     true,
  confirmThreshold:       5,
  showHighlightedSection: false,
  openUniqueOnly:         true,
  scrollToTable:          true,
  searchEngine:           'google',
  searchOpenMode:         'foreground',
  eventHuntersEnabled:    false,
  sortCol:                0,
  sortAsc:                true
};

function timestamp() {
  const d = new Date();
  return d.getFullYear() +
    String(d.getMonth()+1).padStart(2,'0') +
    String(d.getDate()).padStart(2,'0') + 'T' +
    String(d.getHours()).padStart(2,'0') +
    String(d.getMinutes()).padStart(2,'0');
}

function showStatus(msg, type = 'success') {
  const el = document.getElementById('status-msg');
  el.textContent = msg;
  el.className = type === 'success' ? 'msg-success' : 'msg-error';
  el.style.display = 'block';
  setTimeout(() => { el.style.display = 'none'; }, 3500);
}

function getMatchMode() {
  const el = document.querySelector('input[name="matchMode"]:checked');
  return el ? el.value : 'both';
}

function getFormValues() {
  return {
    filterWords:            document.getElementById('filterWords').value,
    highlightWords:         document.getElementById('highlightWords').value,
    matchMode:              getMatchMode(),
    highlightColor:         document.getElementById('highlightColor').value,
    fontSize:               parseInt(document.getElementById('fontSize').value) || 16,
    linkOpenMode:           document.getElementById('linkOpenMode').value,
    openUniqueOnly:         document.getElementById('openUniqueOnly').checked,
    scrollToTable:          document.getElementById('scrollToTable').checked,
    newTabMode:             document.getElementById('newTabMode').value,
    highlightTabMode:       document.getElementById('highlightTabMode').value,
    openOnlyHighlighted:    document.getElementById('openOnlyHighlighted').checked,
    autoOpenHighlighted:    document.getElementById('autoOpenHighlighted').checked,
    confirmHighlighted:     document.getElementById('confirmHighlighted').checked,
    confirmThreshold:       parseInt(document.getElementById('confirmThreshold').value) || 5,
    showHighlightedSection: document.getElementById('showHighlightedSection').checked,
    searchEngine:           document.getElementById('searchEngine').value,
    searchOpenMode:         document.getElementById('searchOpenMode').value,
    eventHuntersEnabled:    document.getElementById('eventHuntersEnabled').checked,
    sortCol:                parseInt(document.getElementById('sortCol').value) || 0,
    sortAsc:                document.getElementById('sortAsc').value === 'true'
  };
}

function applyToForm(s) {
  document.getElementById('filterWords').value              = s.filterWords         || '';
  document.getElementById('highlightWords').value           = s.highlightWords      || '';
  const mode = s.matchMode || 'both';
  const radio = document.querySelector(`input[name="matchMode"][value="${mode}"]`);
  if (radio) radio.checked = true;
  document.getElementById('highlightColor').value           = s.highlightColor      || '#ffff00';
  document.getElementById('colorHex').textContent           = s.highlightColor      || '#ffff00';
  document.getElementById('fontSize').value                 = s.fontSize            || 16;
  document.getElementById('linkOpenMode').value             = s.linkOpenMode        || 'foreground';
  document.getElementById('openUniqueOnly').checked         = s.openUniqueOnly !== false;
  document.getElementById('scrollToTable').checked          = s.scrollToTable !== false;
  document.getElementById('newTabMode').value               = s.newTabMode          || 'foreground';
  document.getElementById('highlightTabMode').value         = s.highlightTabMode    || 'foreground';
  document.getElementById('openOnlyHighlighted').checked    = !!s.openOnlyHighlighted;
  document.getElementById('autoOpenHighlighted').checked    = !!s.autoOpenHighlighted;
  document.getElementById('confirmHighlighted').checked     = s.confirmHighlighted !== false;
  document.getElementById('confirmThreshold').value         = s.confirmThreshold !== undefined ? s.confirmThreshold : 5;
  document.getElementById('showHighlightedSection').checked = !!s.showHighlightedSection;
  document.getElementById('searchEngine').value             = s.searchEngine        || 'google';
  document.getElementById('searchOpenMode').value           = s.searchOpenMode      || 'foreground';
  document.getElementById('eventHuntersEnabled').checked    = !!s.eventHuntersEnabled;
  document.getElementById('sortCol').value                  = String(s.sortCol !== undefined ? s.sortCol : 0);
  document.getElementById('sortAsc').value                  = String(s.sortAsc !== undefined ? s.sortAsc : true);
  document.getElementById('thresholdRow').style.opacity     = document.getElementById('confirmHighlighted').checked ? '1' : '0.4';
}

// Live colour preview
document.getElementById('highlightColor').addEventListener('input', e => {
  document.getElementById('colorHex').textContent = e.target.value;
});

// Threshold row dim toggle
document.getElementById('confirmHighlighted').addEventListener('change', e => {
  document.getElementById('thresholdRow').style.opacity = e.target.checked ? '1' : '0.4';
});

// Save
document.getElementById('saveBtn').addEventListener('click', async () => {
  try {
    await browser.storage.local.set(getFormValues());
    showStatus('✓ Settings saved! They persist across restarts and reloads.', 'success');
  } catch (e) {
    showStatus('✗ Save failed: ' + e.message, 'error');
  }
});

// Export JSON
document.getElementById('exportBtn').addEventListener('click', async () => {
  try {
    const data = { ...getFormValues(), _exported: new Date().toISOString(), _version: '9.0' };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = `url-extractor-settings-${timestamp()}.json`; a.click();
    URL.revokeObjectURL(url);
    showStatus('✓ Settings exported!', 'success');
  } catch (e) {
    showStatus('✗ Export failed: ' + e.message, 'error');
  }
});

// Import JSON
document.getElementById('importBtn').addEventListener('click', () => {
  document.getElementById('importFile').click();
});
document.getElementById('importFile').addEventListener('change', async e => {
  const file = e.target.files[0]; if (!file) return;
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    delete data._exported; delete data._version;
    const cleaned = {};
    Object.keys(DEFAULTS).forEach(k => { if (data[k] !== undefined) cleaned[k] = data[k]; });
    applyToForm({ ...DEFAULTS, ...cleaned });
    await browser.storage.local.set(cleaned);
    showStatus('✓ Settings imported and saved!', 'success');
  } catch (err) {
    showStatus('✗ Import failed: ' + err.message, 'error');
  }
  e.target.value = '';
});

// Reset
document.getElementById('resetBtn').addEventListener('click', async () => {
  if (!confirm('Reset all settings to defaults?')) return;
  try {
    await browser.storage.local.set(DEFAULTS);
    applyToForm(DEFAULTS);
    showStatus('✓ Reset to defaults!', 'success');
  } catch (e) {
    showStatus('✗ Reset failed: ' + e.message, 'error');
  }
});

// Auto-save on any input change
document.addEventListener('change', () => {
  browser.storage.local.set(getFormValues()).catch(() => {});
});

// Init
browser.storage.local.get(DEFAULTS).then(applyToForm);
