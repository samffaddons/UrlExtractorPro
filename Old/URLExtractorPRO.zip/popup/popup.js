document.getElementById('extractBtn').addEventListener('click', async () => {
  const tabs = await browser.tabs.query({ active: true, currentWindow: true });
  if (tabs[0]) {
    browser.tabs.sendMessage(tabs[0].id, { action: 'extractURLs' });
    window.close();
  }
});

document.getElementById('openOptionsBtn').addEventListener('click', () => {
  // Open options in a new tab
  browser.tabs.create({ url: browser.runtime.getURL('options/options.html') });
  window.close();
});
