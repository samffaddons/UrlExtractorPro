/* URL Extractor Pro v5 — New Tab Results Page */

let allUrls       = [];
let special       = { mailto: [], tel: [], linkedin: [] };
let currentSorted = [];
let settings      = {};
let fontSize      = 16;
let sortCol       = 0;
let sortAsc       = true;
let quickFilter   = '';
const checkedMap  = new Map();

// ─── Utilities ────────────────────────────────────────────────────────────────

function escapeCsv(val) { return `"${String(val).replace(/"/g, '""')}"` }

function uniqueByUrl(items) {
  const seen = new Set();
  return items.filter(item => {
    const k = item.url.toLowerCase();
    if (seen.has(k)) return false;
    seen.add(k); return true;
  });
}

function showConfirmDialog({ title, message, confirmLabel, cancelLabel }) {
  return new Promise(resolve => {
    const overlay = document.createElement('div');
    overlay.style.cssText = `position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:99999;display:flex;align-items:center;justify-content:center;`;
    const box = document.createElement('div');
    box.style.cssText = `background:#fff;border-radius:12px;padding:28px 30px;max-width:440px;width:90%;box-shadow:0 8px 32px rgba(0,0,0,0.28);font-family:Arial,sans-serif;font-size:15px;color:#222;`;
    const h = document.createElement('div');
    h.style.cssText = 'font-size:18px;font-weight:bold;color:#e67e22;margin-bottom:14px;';
    h.textContent = title;
    const msg = document.createElement('div');
    msg.style.cssText = 'line-height:1.6;margin-bottom:22px;color:#333;';
    msg.innerHTML = message;
    const btnRow = document.createElement('div');
    btnRow.style.cssText = 'display:flex;gap:12px;justify-content:flex-end;';
    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = cancelLabel || 'Cancel';
    cancelBtn.style.cssText = 'padding:9px 20px;border:1px solid #ccc;border-radius:6px;background:#f0f0f0;color:#333;font-size:14px;font-weight:600;cursor:pointer;';
    cancelBtn.addEventListener('click', () => { overlay.remove(); resolve(false); });
    const confirmBtn = document.createElement('button');
    confirmBtn.textContent = confirmLabel || 'Continue';
    confirmBtn.style.cssText = 'padding:9px 20px;border:none;border-radius:6px;background:#e67e22;color:#fff;font-size:14px;font-weight:600;cursor:pointer;';
    confirmBtn.addEventListener('click', () => { overlay.remove(); resolve(true); });
    overlay.addEventListener('click', e => { if (e.target === overlay) { overlay.remove(); resolve(false); } });
    btnRow.appendChild(cancelBtn); btnRow.appendChild(confirmBtn);
    box.appendChild(h); box.appendChild(msg); box.appendChild(btnRow);
    overlay.appendChild(box);
    document.body.appendChild(overlay);
    confirmBtn.focus();
  });
}

function timestamp() {
  const d = new Date();
  return d.getFullYear() + String(d.getMonth()+1).padStart(2,'0') + String(d.getDate()).padStart(2,'0')
    + 'T' + String(d.getHours()).padStart(2,'0') + String(d.getMinutes()).padStart(2,'0');
}

function downloadFile(content, filename, mime) {
  const blob = new Blob([content], { type: mime });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a'); a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

// ─── Match helper (mirrors content.js) ────────────────────────────────────────

function wordMatches(item, words, matchMode) {
  return words.some(w => {
    const inText = item.text.toLowerCase().includes(w);
    const inUrl  = item.url.toLowerCase().includes(w) || (item.rawHref || '').toLowerCase().includes(w);
    if (matchMode === 'text') return inText;
    if (matchMode === 'url')  return inUrl;
    return inText || inUrl;
  });
}

function getHlWords() {
  return (settings.highlightWords || '').split('\n').map(w => w.trim().toLowerCase()).filter(Boolean);
}

function isHighlighted(item) {
  const words = getHlWords();
  return words.length > 0 && wordMatches(item, words, settings.matchMode || 'both');
}

function itemKey(item) { return item.text + '|||' + item.url; }

// ─── Special rows (mailto / tel / linkedin) ───────────────────────────────────

// ─── Search engine helpers ─────────────────────────────────────────────────────

const SEARCH_ENGINES = {
  google:     q => `https://www.google.com/search?q=${encodeURIComponent(q)}`,
  bing:       q => `https://www.bing.com/search?q=${encodeURIComponent(q)}`,
  duckduckgo: q => `https://duckduckgo.com/?q=${encodeURIComponent(q)}`,
  ecosia:     q => `https://www.ecosia.org/search?q=${encodeURIComponent(q)}`,
  yandex:     q => `https://yandex.com/search/?text=${encodeURIComponent(q)}`,
  startpage:  q => `https://www.startpage.com/search?q=${encodeURIComponent(q)}`,
  qwant:      q => `https://www.qwant.com/?q=${encodeURIComponent(q)}`,
  yahoo:      q => `https://search.yahoo.com/search?p=${encodeURIComponent(q)}`,
  brave:      q => `https://search.brave.com/search?q=${encodeURIComponent(q)}`,
  searx:      q => `https://searx.be/search?q=${encodeURIComponent(q)}`
};

function buildSearchUrl(query, engine) {
  const fn = SEARCH_ENGINES[engine] || SEARCH_ENGINES.google;
  return fn(query);
}

// ─── Domain Search rows ────────────────────────────────────────────────────────

function buildDomainSearchRows() {
  const rows    = [];
  const pageUrl = settings._pageUrl || '';
  const eng     = settings.searchEngine   || 'google';
  const sMode   = settings.searchOpenMode || 'foreground';
  if (!pageUrl) return rows;

  let fullHostname = '';
  try { fullHostname = new URL(pageUrl).hostname; } catch (e) { return rows; }
  if (!fullHostname) return rows;

  const cleanHostname = fullHostname.replace(/^www\./, '');
  const parts         = cleanHostname.split('.');
  const rootDomain    = parts.length > 2 ? parts.slice(-2).join('.') : cleanHostname;
  const hasSubdomain  = parts.length > 2;

  const bg        = '#fafafa';
  const cellStyle = 'padding:7px 12px;border:1px solid #dde3ed;word-break:break-word;';
  const numStyle  = 'text-align:center;color:#aaa;font-size:12px;padding:7px;width:44px;white-space:nowrap;border:1px solid #dde3ed;';
  const cbStyle   = 'text-align:center;width:36px;padding:5px;border:1px solid #dde3ed;';

  function makeSearchSet(domain, sectionLabel, sectionColor) {
    const atDomain = '@' + domain;
    const hdrTr = document.createElement('tr');
    const hdrTd = document.createElement('td');
    hdrTd.colSpan = 5;
    hdrTd.style.cssText = `padding:9px 14px;background:${sectionColor};font-weight:bold;font-size:13px;color:#fff;border:1px solid #dde3ed;letter-spacing:0.3px;`;
    hdrTd.textContent = sectionLabel;
    hdrTr.appendChild(hdrTd); rows.push(hdrTr);

    const searches = [
      { label: `Search ${domain}`,                   query: domain },
      { label: `Search ${atDomain} emails`,          query: `${atDomain} emails` },
      { label: `Search ${atDomain} staff`,           query: `${atDomain} staff` },
      { label: `Search ${atDomain} board`,           query: `${atDomain} board` },
      { label: `Search ${atDomain} team`,            query: `${atDomain} team` },
      { label: `Search ${atDomain} linkedin`,        query: `${atDomain} linkedin` },
      { label: `Search ${atDomain} phone number`,    query: `${atDomain} phone number` },
      { label: `Search ${atDomain} Media Contacts`,  query: `${atDomain} Media Contacts` },
    ];

    searches.forEach(({ label, query }) => {
      const searchUrl = buildSearchUrl(query, eng);
      const tr = document.createElement('tr'); tr.style.cssText = `background:${bg};cursor:pointer;`;
      const tdCb = document.createElement('td'); tdCb.style.cssText = cbStyle; tr.appendChild(tdCb);
      const tdNum = document.createElement('td'); tdNum.textContent = '—'; tdNum.style.cssText = numStyle; tr.appendChild(tdNum);
      const tdLabel = document.createElement('td'); tdLabel.style.cssText = cellStyle;
      const aLabel = document.createElement('a'); aLabel.href = searchUrl; aLabel.textContent = label;
      aLabel.style.cssText = 'color:#4a148c;text-decoration:none;font-weight:600;';
      aLabel.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); window.open(searchUrl, '_blank'); });
      tdLabel.appendChild(aLabel); tr.appendChild(tdLabel);
      const tdUrl = document.createElement('td'); tdUrl.style.cssText = cellStyle + 'word-break:break-all;';
      const aUrl = document.createElement('a'); aUrl.href = searchUrl; aUrl.textContent = searchUrl;
      aUrl.style.cssText = 'color:#6a1b9a;text-decoration:none;font-size:0.82em;';
      aUrl.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); window.open(searchUrl, '_blank'); });
      tdUrl.appendChild(aUrl); tr.appendChild(tdUrl);
      const tdTop = document.createElement('td'); tdTop.style.cssText = 'padding:4px 6px;border:1px solid #dde3ed;text-align:center;width:32px;';
      const topBtn = document.createElement('button'); topBtn.textContent = '↑'; topBtn.title = 'Go to top';
      topBtn.style.cssText = 'background:transparent;border:1px solid #bbb;border-radius:3px;cursor:pointer;font-size:12px;color:#666;padding:2px 5px;';
      topBtn.addEventListener('click', e => { e.stopPropagation(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
      tdTop.appendChild(topBtn); tr.appendChild(tdTop);
      tr.addEventListener('click', () => window.open(searchUrl, '_blank'));
      rows.push(tr);
    });
  }

  // Root domain rows (always)
  makeSearchSet(rootDomain, `🔎  Domain Search — ${rootDomain}`, '#4a148c');

  // Subdomain rows (only if subdomain present)
  if (hasSubdomain) {
    makeSearchSet(cleanHostname, `🔎  Subdomain Search — ${cleanHostname}`, '#6a1b9a');
  }

  // Clipboard search row — both label and URL cells are clickable
  const doClipSearch = async (e) => {
    if (e) { e.preventDefault(); e.stopPropagation(); }
    try {
      const text = await navigator.clipboard.readText();
      if (!text.trim()) { alert('Clipboard is empty.'); return; }
      window.open(buildSearchUrl(text.trim(), eng), '_blank');
    } catch (err) { alert('Could not read clipboard.'); }
  };

  const clipTr = document.createElement('tr'); clipTr.style.cssText = `background:${bg};cursor:pointer;`;
  const clipCb = document.createElement('td'); clipCb.style.cssText = cbStyle; clipTr.appendChild(clipCb);
  const clipNum = document.createElement('td'); clipNum.textContent = '—'; clipNum.style.cssText = numStyle; clipTr.appendChild(clipNum);

  const clipLabel = document.createElement('td'); clipLabel.style.cssText = cellStyle;
  const clipA = document.createElement('a'); clipA.href = '#'; clipA.textContent = 'Search Clipboard Content';
  clipA.style.cssText = 'color:#4a148c;text-decoration:none;font-weight:600;';
  clipA.addEventListener('click', doClipSearch);
  clipLabel.appendChild(clipA); clipTr.appendChild(clipLabel);

  // URL cell — also clickable, same action
  const clipUrl = document.createElement('td'); clipUrl.style.cssText = cellStyle + 'word-break:break-all;';
  const clipUrlA = document.createElement('a'); clipUrlA.href = '#'; clipUrlA.textContent = 'Search Clipboard Content';
  clipUrlA.style.cssText = 'color:#6a1b9a;text-decoration:none;font-size:0.9em;font-weight:600;';
  clipUrlA.addEventListener('click', doClipSearch);
  clipUrl.appendChild(clipUrlA); clipTr.appendChild(clipUrl);

  const clipTop = document.createElement('td'); clipTop.style.cssText = 'padding:4px 6px;border:1px solid #dde3ed;text-align:center;width:32px;';
  const clipTopBtn = document.createElement('button'); clipTopBtn.textContent = '↑';
  clipTopBtn.style.cssText = 'background:transparent;border:1px solid #bbb;border-radius:3px;cursor:pointer;font-size:12px;color:#666;padding:2px 5px;';
  clipTopBtn.addEventListener('click', e => { e.stopPropagation(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
  clipTop.appendChild(clipTopBtn); clipTr.appendChild(clipTop);
  clipTr.addEventListener('click', doClipSearch);
  rows.push(clipTr);

  return rows;
}

function buildSpecialRows() {
  const rows       = [];
  const hlWords    = getHlWords();
  const matchMode  = settings.matchMode || 'both';
  const hlColor    = settings.highlightColor || '#ffff00';
  const eng        = settings.searchEngine   || 'google';
  const sMode      = settings.searchOpenMode || 'foreground';
  const cellStyle  = 'padding:7px 12px;border:1px solid #dde3ed;word-break:break-word;';
  const numStyle   = 'text-align:center;color:#aaa;font-size:12px;padding:7px;width:44px;white-space:nowrap;border:1px solid #dde3ed;';
  const cbStyle    = 'text-align:center;width:36px;padding:5px;border:1px solid #dde3ed;';

  function makeSection(label, color) {
    const tr = document.createElement('tr');
    const td = document.createElement('td');
    td.colSpan = 5;
    td.style.cssText = `padding:9px 14px;background:${color};font-weight:bold;font-size:13px;color:#fff;border:1px solid #dde3ed;letter-spacing:0.3px;`;
    td.textContent = label;
    tr.appendChild(td);
    rows.push(tr);
  }

  function makeRow(label, displayUrl, href, copyValue) {
    const key     = label + '|||' + (href || displayUrl);
    const checked = checkedMap.get(key) !== false;
    const fakeItem = { text: label, url: href || displayUrl, rawHref: href || '' };
    const hl       = hlWords.length > 0 && wordMatches(fakeItem, hlWords, matchMode);
    const bg       = hl ? hlColor : '#fff';

    const tr = document.createElement('tr');
    tr.style.background = bg;
    tr.style.cursor = 'pointer';

    const tdCb = document.createElement('td');
    tdCb.style.cssText = cbStyle;
    const cb = document.createElement('input');
    cb.type = 'checkbox'; cb.checked = checked;
    cb.style.cssText = 'width:15px;height:15px;cursor:pointer;';
    cb.addEventListener('change', e => { e.stopPropagation(); checkedMap.set(key, cb.checked); });
    tdCb.appendChild(cb); tr.appendChild(tdCb);

    const tdNum = document.createElement('td');
    tdNum.textContent = '—';
    tdNum.style.cssText = numStyle;
    tr.appendChild(tdNum);

    const tdText = document.createElement('td');
    tdText.style.cssText = cellStyle;
    if (href) {
      const a = document.createElement('a');
      a.href = href; a.title = href; a.textContent = label;
      a.target = '_blank'; a.rel = 'noopener noreferrer';
      a.addEventListener('click', e => e.stopPropagation());
      tdText.appendChild(a);
    } else {
      tdText.textContent = label;
      tdText.style.cssText += 'color:#333;font-style:italic;';
    }
    tr.appendChild(tdText);

    const tdUrl = document.createElement('td');
    tdUrl.style.cssText = cellStyle + 'word-break:break-all;';

    // Flex wrapper so copy button sits inline after value
    const urlWrap = document.createElement('span');
    urlWrap.style.cssText = 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;';

    if (href) {
      const a = document.createElement('a');
      a.href = href; a.title = href; a.textContent = displayUrl;
      a.className = 'url-link';
      a.target = '_blank'; a.rel = 'noopener noreferrer';
      a.addEventListener('click', e => e.stopPropagation());
      urlWrap.appendChild(a);
    } else {
      const span = document.createElement('span');
      span.textContent = displayUrl;
      span.style.cssText = 'color:#444;font-size:0.9em;flex:1;';
      urlWrap.appendChild(span);
    }

    // Copy button — only for tel rows
    if (copyValue !== undefined && copyValue !== null) {
      const copyBtn = document.createElement('button');
      copyBtn.textContent = '📋 Copy';
      copyBtn.title = 'Copy to clipboard: ' + copyValue;
      copyBtn.style.cssText = `
        background:#1565c0;color:#fff;border:none;padding:3px 9px;border-radius:4px;
        cursor:pointer;font-size:11px;font-weight:600;white-space:nowrap;flex-shrink:0;
      `;
      copyBtn.addEventListener('click', e => {
        e.stopPropagation();
        navigator.clipboard.writeText(copyValue).then(() => {
          copyBtn.textContent = '✓ Copied!';
          copyBtn.style.background = '#2e7d32';
          setTimeout(() => {
            copyBtn.textContent = '📋 Copy';
            copyBtn.style.background = '#1565c0';
          }, 1800);
        }).catch(() => {
          copyBtn.textContent = '✗ Failed';
          setTimeout(() => { copyBtn.textContent = '📋 Copy'; }, 1800);
        });
      });
      urlWrap.appendChild(copyBtn);
    }

    tdUrl.appendChild(urlWrap);
    tr.appendChild(tdUrl);

    tr.addEventListener('click', () => { cb.checked = !cb.checked; checkedMap.set(key, cb.checked); });
    rows.push(tr);
  }

  // Mailto
  if (special.mailto && special.mailto.length > 0) {
    makeSection('📧  Mailto Links', '#2e7d32');
    special.mailto.forEach(item => {
      const key = item.text + '|||' + item.url;
      checkedMap.set(key, true);
      const fakeItem = { text: item.text, url: item.url, rawHref: item.rawHref || '' };
      const hl  = hlWords.length > 0 && wordMatches(fakeItem, hlWords, matchMode);
      const bg  = hl ? hlColor : '#fff';
      const tr  = document.createElement('tr');
      tr.style.cssText = `background:${bg};cursor:pointer;`;

      const tdCb = document.createElement('td'); tdCb.style.cssText = cbStyle;
      const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = true;
      cb.style.cssText = 'width:15px;height:15px;cursor:pointer;';
      cb.addEventListener('change', e => { e.stopPropagation(); checkedMap.set(key, cb.checked); });
      tdCb.appendChild(cb); tr.appendChild(tdCb);

      const tdNum = document.createElement('td'); tdNum.textContent = '—'; tdNum.style.cssText = numStyle; tr.appendChild(tdNum);

      const tdText = document.createElement('td'); tdText.style.cssText = cellStyle;
      const aText = document.createElement('a'); aText.href = item.url; aText.textContent = item.text;
      aText.target = '_blank'; aText.rel = 'noopener noreferrer';
      aText.addEventListener('click', e => e.stopPropagation());
      tdText.appendChild(aText); tr.appendChild(tdText);

      const tdUrl = document.createElement('td'); tdUrl.style.cssText = cellStyle + 'word-break:break-all;';
      const wrap = document.createElement('span'); wrap.style.cssText = 'display:flex;align-items:center;gap:6px;flex-wrap:wrap;';
      const aEmail = document.createElement('a'); aEmail.href = item.url; aEmail.textContent = item.display;
      aEmail.className = 'url-link'; aEmail.target = '_blank'; aEmail.rel = 'noopener noreferrer';
      aEmail.addEventListener('click', e => e.stopPropagation());
      wrap.appendChild(aEmail);

      const btnQ = document.createElement('button');
      btnQ.textContent = '🔍 "quotes"'; btnQ.title = `Search "${item.display}" with quotes`;
      btnQ.style.cssText = 'background:#1b5e20;color:#fff;border:none;padding:3px 8px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:600;white-space:nowrap;';
      btnQ.addEventListener('click', e => {
        e.stopPropagation();
        window.open(buildSearchUrl(`"${item.display}"`, eng), sMode === 'background' ? '_blank' : '_self');
      });
      wrap.appendChild(btnQ);

      const btnNoQ = document.createElement('button');
      btnNoQ.textContent = '🔍 no quotes'; btnNoQ.title = `Search ${item.display} without quotes`;
      btnNoQ.style.cssText = 'background:#2e7d32;color:#fff;border:none;padding:3px 8px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:600;white-space:nowrap;';
      btnNoQ.addEventListener('click', e => {
        e.stopPropagation();
        window.open(buildSearchUrl(item.display, eng), sMode === 'background' ? '_blank' : '_self');
      });
      wrap.appendChild(btnNoQ);

      tdUrl.appendChild(wrap); tr.appendChild(tdUrl);

      const tdTop = document.createElement('td'); tdTop.style.cssText = 'padding:4px 6px;border:1px solid #dde3ed;text-align:center;width:32px;';
      const topBtn = document.createElement('button'); topBtn.textContent = '↑'; topBtn.title = 'Go to top';
      topBtn.style.cssText = 'background:transparent;border:1px solid #bbb;border-radius:3px;cursor:pointer;font-size:12px;color:#666;padding:2px 5px;';
      topBtn.addEventListener('click', e => { e.stopPropagation(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
      tdTop.appendChild(topBtn); tr.appendChild(tdTop);

      tr.addEventListener('click', () => { cb.checked = !cb.checked; checkedMap.set(key, cb.checked); });
      rows.push(tr);
    });
  }

  // Tel
  if (special.tel && special.tel.length > 0) {
    makeSection('📞  Tel Links', '#1565c0');
    if (special.tel.length === 1) {
      const t = special.tel[0];
      checkedMap.set(t.num + '|||' + t.url, true);
      makeRow(t.num, t.num, t.url, t.num);
    } else {
      special.tel.forEach(t => {
        checkedMap.set(t.num + '|||' + t.url, true);
        makeRow(t.num, t.num, t.url, t.num);
      });
      const combined    = special.tel.map(t => t.num).join(' // ');
      const summaryKey  = 'All Tel: Links|||' + combined;
      checkedMap.set(summaryKey, true);
      makeRow('All Tel: Links', combined, null, combined);
    }
  }

  // LinkedIn
  if (special.linkedin && special.linkedin.length > 0) {
    makeSection('💼  LinkedIn URLs', '#0a66c2');
    special.linkedin.forEach(item => {
      checkedMap.set(item.text + '|||' + item.url, true);
      makeRow(item.text, item.url, item.url);
    });
  }

  return rows;
}

// ─── Page Info rows ────────────────────────────────────────────────────────────

function buildPageInfoRows() {
  const rows      = [];
  const pageTitle = settings._pageTitle || '';
  const pageUrl   = settings._pageUrl   || '';
  if (!pageTitle && !pageUrl) return rows;

  const cellStyle = 'padding:7px 12px;border:1px solid #dde3ed;word-break:break-word;';
  const numStyle  = 'text-align:center;color:#aaa;font-size:12px;padding:7px;width:44px;white-space:nowrap;border:1px solid #dde3ed;';
  const cbStyle   = 'text-align:center;width:36px;padding:5px;border:1px solid #dde3ed;';

  // Section header
  const hdrTr = document.createElement('tr');
  const hdrTd = document.createElement('td');
  hdrTd.colSpan = 5;
  hdrTd.style.cssText = 'padding:9px 14px;background:#37474f;font-weight:bold;font-size:13px;color:#fff;border:1px solid #dde3ed;letter-spacing:0.3px;';
  hdrTd.textContent = '🌐  Current Page';
  hdrTr.appendChild(hdrTd);
  rows.push(hdrTr);

  function makeInfoRow(labelText, valueText, valueHref, copyValue) {
    const tr = document.createElement('tr');
    tr.style.cssText = 'background:#eceff1;';

    // Empty checkbox placeholder
    const tdCb = document.createElement('td');
    tdCb.style.cssText = cbStyle; tr.appendChild(tdCb);

    // Dash
    const tdNum = document.createElement('td');
    tdNum.textContent = '—'; tdNum.style.cssText = numStyle; tr.appendChild(tdNum);

    // Label
    const tdLabel = document.createElement('td');
    tdLabel.style.cssText = cellStyle + 'font-weight:bold;color:#333;font-size:0.9em;white-space:nowrap;';
    tdLabel.textContent = labelText; tr.appendChild(tdLabel);

    // Value + copy button
    const tdVal = document.createElement('td');
    tdVal.style.cssText = cellStyle + 'word-break:break-all;';
    const wrap = document.createElement('span');
    wrap.style.cssText = 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;';

    if (valueHref) {
      const a = document.createElement('a');
      a.href = valueHref; a.title = valueHref; a.textContent = valueText;
      a.className = 'url-link'; a.target = '_blank'; a.rel = 'noopener noreferrer';
      wrap.appendChild(a);
    } else {
      const span = document.createElement('span');
      span.textContent = valueText;
      span.style.cssText = 'color:#333;font-size:0.92em;flex:1;';
      wrap.appendChild(span);
    }

    if (copyValue) {
      const copyBtn = document.createElement('button');
      copyBtn.textContent = '📋 Copy';
      copyBtn.title = 'Copy: ' + copyValue;
      copyBtn.style.cssText = 'background:#37474f;color:#fff;border:none;padding:3px 9px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:600;white-space:nowrap;flex-shrink:0;';
      copyBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(copyValue).then(() => {
          copyBtn.textContent = '✓ Copied!'; copyBtn.style.background = '#2e7d32';
          setTimeout(() => { copyBtn.textContent = '📋 Copy'; copyBtn.style.background = '#37474f'; }, 1800);
        }).catch(() => {
          copyBtn.textContent = '✗ Failed';
          setTimeout(() => { copyBtn.textContent = '📋 Copy'; }, 1800);
        });
      });
      wrap.appendChild(copyBtn);
    }

    tdVal.appendChild(wrap); tr.appendChild(tdVal);

    // ↑ top
    const tdTop = document.createElement('td');
    tdTop.style.cssText = 'padding:4px 6px;border:1px solid #dde3ed;text-align:center;width:32px;';
    const topBtn = document.createElement('button');
    topBtn.textContent = '↑'; topBtn.title = 'Go to top';
    topBtn.style.cssText = 'background:transparent;border:1px solid #bbb;border-radius:3px;cursor:pointer;font-size:12px;color:#666;padding:2px 5px;';
    topBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
    tdTop.appendChild(topBtn); tr.appendChild(tdTop);

    rows.push(tr);
  }

  if (pageTitle) makeInfoRow('📄 Page Title', pageTitle, null, pageTitle);
  if (pageUrl)   makeInfoRow('🔗 Page URL',   pageUrl,   pageUrl, pageUrl);

  return rows;
}

function renderTable(list) {
  const tbody      = document.getElementById('tbody');
  const table      = document.getElementById('urlTable');
  const emptyState = document.getElementById('emptyState');
  const countEl    = document.getElementById('count-display');

  list = [...list].sort((a, b) => {
    const va = sortCol === 0 ? a.text : a.url;
    const vb = sortCol === 0 ? b.text : b.url;
    return sortAsc ? va.localeCompare(vb) : vb.localeCompare(va);
  });
  currentSorted = list;

  document.getElementById('th-text').textContent = 'Link Text ' + (sortCol===0 ? (sortAsc?'▲':'▼') : '');
  document.getElementById('th-url').textContent  = 'URL '       + (sortCol===1 ? (sortAsc?'▲':'▼') : '');

  countEl.textContent = `${list.length} URL(s)${list.length !== allUrls.length ? ` (filtered from ${allUrls.length})` : ''}`;

  const hasSpecial = (special.mailto && special.mailto.length > 0) ||
                     (special.tel    && special.tel.length    > 0) ||
                     (special.linkedin && special.linkedin.length > 0) ||
                     !!(settings._pageTitle || settings._pageUrl);

  if (list.length === 0 && !hasSpecial) {
    table.style.display = 'none'; emptyState.style.display = 'block'; return;
  }
  table.style.display = 'table'; emptyState.style.display = 'none';
  table.style.fontSize = fontSize + 'px';

  const hlColor = settings.highlightColor || '#ffff00';

  tbody.innerHTML = '';

  // Regular rows
  list.forEach((item, idx) => {
    const key     = itemKey(item);
    const hl      = isHighlighted(item);
    const checked = checkedMap.get(key) !== false;

    const tr = document.createElement('tr');
    tr.style.background = hl ? hlColor : (idx % 2 === 0 ? '#f9f9f9' : '#fff');
    tr.style.cursor = 'pointer';

    const tdCb = document.createElement('td');
    tdCb.style.cssText = 'text-align:center;width:36px;padding:5px;border:1px solid #dde3ed;';
    const cb = document.createElement('input');
    cb.type = 'checkbox'; cb.checked = checked;
    cb.style.cssText = 'width:15px;height:15px;cursor:pointer;';
    cb.addEventListener('change', e => { e.stopPropagation(); checkedMap.set(key, cb.checked); });
    tdCb.appendChild(cb); tr.appendChild(tdCb);

    const tdNum = document.createElement('td');
    tdNum.textContent = idx + 1;
    tdNum.style.cssText = 'text-align:center;color:#aaa;font-size:12px;padding:7px;width:44px;white-space:nowrap;border:1px solid #dde3ed;';
    tr.appendChild(tdNum);

    const tdText = document.createElement('td');
    tdText.style.cssText = 'padding:7px 12px;border:1px solid #dde3ed;word-break:break-word;';
    const aText = document.createElement('a');
    aText.href = item.url; aText.title = item.url; aText.textContent = item.text;
    aText.style.cssText = item.noTitle ? 'color:#999;text-decoration:none;font-style:italic;' : '';
    aText.target = '_blank'; aText.rel = 'noopener noreferrer';
    aText.addEventListener('click', e => e.stopPropagation());
    tdText.appendChild(aText); tr.appendChild(tdText);

    const tdUrl = document.createElement('td');
    tdUrl.style.cssText = 'padding:7px 12px;border:1px solid #dde3ed;word-break:break-all;';
    const aUrl = document.createElement('a');
    aUrl.href = item.url; aUrl.title = item.url; aUrl.textContent = item.url;
    aUrl.className = 'url-link'; aUrl.target = '_blank'; aUrl.rel = 'noopener noreferrer';
    aUrl.addEventListener('click', e => e.stopPropagation());
    tdUrl.appendChild(aUrl); tr.appendChild(tdUrl);

    // ↑ Go to top
    const tdTop = document.createElement('td');
    tdTop.style.cssText = 'padding:4px 6px;border:1px solid #dde3ed;text-align:center;width:32px;';
    const topBtn = document.createElement('button');
    topBtn.textContent = '↑'; topBtn.title = 'Go to top of page';
    topBtn.style.cssText = 'background:transparent;border:1px solid #bbb;border-radius:3px;cursor:pointer;font-size:12px;color:#666;padding:2px 5px;';
    topBtn.addEventListener('click', e => { e.stopPropagation(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
    tdTop.appendChild(topBtn); tr.appendChild(tdTop);

    tr.addEventListener('click', () => { cb.checked = !cb.checked; checkedMap.set(key, cb.checked); });
    tbody.appendChild(tr);
  });

  // Always append special rows at the end
  buildSpecialRows().forEach(tr => tbody.appendChild(tr));

  // Domain search rows
  buildDomainSearchRows().forEach(tr => tbody.appendChild(tr));

  // Always append current page info rows at the very bottom
  buildPageInfoRows().forEach(tr => tbody.appendChild(tr));
}

function applyQuickFilter() {
  if (!quickFilter) { renderTable(allUrls); return; }
  const qf = quickFilter.toLowerCase();
  renderTable(allUrls.filter(i =>
    i.text.toLowerCase().includes(qf) ||
    i.url.toLowerCase().includes(qf) ||
    (i.rawHref || '').toLowerCase().includes(qf)
  ));
}

// ─── Sort headers ──────────────────────────────────────────────────────────────
document.getElementById('th-text').addEventListener('click', () => {
  if (sortCol===0) sortAsc=!sortAsc; else { sortCol=0; sortAsc=true; } applyQuickFilter();
});
document.getElementById('th-url').addEventListener('click', () => {
  if (sortCol===1) sortAsc=!sortAsc; else { sortCol=1; sortAsc=true; } applyQuickFilter();
});

// ─── Toolbar ──────────────────────────────────────────────────────────────────

document.getElementById('checkAllBtn').addEventListener('click', () => {
  currentSorted.forEach(i => checkedMap.set(itemKey(i), true)); applyQuickFilter();
});
document.getElementById('uncheckAllBtn').addEventListener('click', () => {
  currentSorted.forEach(i => checkedMap.set(itemKey(i), false)); applyQuickFilter();
});

document.getElementById('openCheckedBtn').addEventListener('click', () => {
  let toOpen = currentSorted.filter(i => checkedMap.get(itemKey(i)) !== false);
  if (settings.openUniqueOnly !== false) toOpen = uniqueByUrl(toOpen);
  if (!toOpen.length) { alert('No checked URLs.'); return; }
  toOpen.forEach(i => window.open(i.url, '_blank'));
});

document.getElementById('openHighlightedBtn').addEventListener('click', async () => {
  let toOpen = currentSorted.filter(isHighlighted);
  toOpen = uniqueByUrl(toOpen); // highlighted always deduplicated
  if (!toOpen.length) { alert('No highlighted URLs. Set highlight words in Settings.'); return; }
  const threshold = (settings.confirmThreshold !== undefined) ? settings.confirmThreshold : 5;
  if (settings.confirmHighlighted !== false && toOpen.length > threshold) {
    const ok = await showConfirmDialog({
      title: '⭐ Open Highlighted URLs',
      message: `You are about to open <strong>${toOpen.length} highlighted URL(s)</strong> in new tabs.<br><br>Do you want to continue?`,
      confirmLabel: `Open ${toOpen.length} tabs`,
      cancelLabel: 'Cancel'
    });
    if (!ok) return;
  }
  toOpen.forEach(i => window.open(i.url, '_blank'));
});

document.getElementById('exportBtn').addEventListener('click', () => {
  const rows = [['Text','URL'], ...currentSorted.map(i => [escapeCsv(i.text), escapeCsv(i.url)])];
  downloadFile(rows.map(r => r.join(',')).join('\n'), 'url-extractor-' + timestamp() + '.csv', 'text/csv');
});

document.getElementById('copyBtn').addEventListener('click', () => {
  const text = ['Text\tURL', ...currentSorted.map(i => `${i.text}\t${i.url}`)].join('\n');
  navigator.clipboard.writeText(text).then(() => {
    const btn = document.getElementById('copyBtn');
    btn.textContent = '✓ Copied!';
    setTimeout(() => { btn.textContent = '📋 Copy Table'; }, 1500);
  });
});

document.getElementById('filterBtn').addEventListener('click', () => {
  quickFilter = document.getElementById('filterInput').value.trim(); applyQuickFilter();
});
document.getElementById('filterInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') { quickFilter = document.getElementById('filterInput').value.trim(); applyQuickFilter(); }
});
document.getElementById('clearFilterBtn').addEventListener('click', () => {
  document.getElementById('filterInput').value = ''; quickFilter = ''; applyQuickFilter();
});

document.getElementById('fontDown').addEventListener('click', () => {
  fontSize = Math.max(8, fontSize - 1);
  document.getElementById('fontSizeDisplay').textContent = fontSize + 'px';
  document.getElementById('urlTable').style.fontSize = fontSize + 'px';
});
document.getElementById('fontUp').addEventListener('click', () => {
  fontSize++;
  document.getElementById('fontSizeDisplay').textContent = fontSize + 'px';
  document.getElementById('urlTable').style.fontSize = fontSize + 'px';
});

document.getElementById('goTop').addEventListener('click', e => {
  e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' });
});

document.getElementById('gotoBottomBtn').addEventListener('click', () => {
  const anchor = document.getElementById('nt-table-bottom-anchor');
  if (anchor) anchor.scrollIntoView({ behavior: 'smooth', block: 'end' });
});

document.getElementById('gotoTableTopBtn').addEventListener('click', () => {
  const table = document.getElementById('urlTable');
  if (table) table.scrollIntoView({ behavior: 'smooth', block: 'start' });
});

document.getElementById('gotoTableStartFromBottom').addEventListener('click', () => {
  const table = document.getElementById('urlTable');
  if (table) table.scrollIntoView({ behavior: 'smooth', block: 'start' });
});

// ─── Init ──────────────────────────────────────────────────────────────────────
async function init() {
  try {
    const data = await browser.runtime.sendMessage({ action: 'getNewTabData' });
    if (data && data.urls) {
      allUrls  = data.urls;
      special  = data.special  || { mailto: [], tel: [], linkedin: [] };
      settings = data.settings || {};
      fontSize = settings.fontSize || 16;
      sortCol  = settings.sortCol  !== undefined ? settings.sortCol  : 0;
      sortAsc  = settings.sortAsc  !== undefined ? settings.sortAsc  : true;
      allUrls.forEach(i => checkedMap.set(itemKey(i), true));
      document.getElementById('fontSizeDisplay').textContent = fontSize + 'px';
      document.getElementById('loading').style.display = 'none';
      applyQuickFilter();
    } else {
      document.getElementById('loading').textContent = '⚠ No URL data. Extract URLs from a page first.';
    }
  } catch (e) {
    document.getElementById('loading').textContent = '⚠ Error: ' + e.message;
  }
}
init();
